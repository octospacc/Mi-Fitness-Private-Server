local lvgl = require("lvgl")

num=0;
objImageGame = {};
board = {};
cell = {};
added={};
zeroSpace=1;
m=4;
n=4;
maxvalue=0;
historyBest=0;
zero=0;
x1,y1,x2,y2=0;


local fsRoot = SCRIPT_PATH
local DEBUG_ENABLE = true

local printf = DEBUG_ENABLE and print or function (...)

end

function imgPath(src)
    return fsRoot .. "game2048/" .. src
end


local function saveContent()
    saveContentW = io.open(fsRoot .."gameContent.txt","w")
    for i=1,m do
        for j=1,n do
            saveContentW:write(board[i][j],",")
            -- saveContentW:write("\n")
        end
    end
    io.close(saveContentW)

end

local function writeBestScore()
    printf("-------writeData----------",maxvalue)
    if type(maxvalue) == "string" then
        maxvalue = tonumber(maxvalue)
    end

    if (maxvalue >= tonumber(historyBest)) then
        historyBest = maxvalue
        historyBestW = io.open(fsRoot .."historyBest.txt","w")
        historyBestW:write(historyBest)
        io.close(historyBestW)
    end
end

local function writeMaxValue()
    maxvalueW = io.open(fsRoot .."maxvalue.txt","w")
    maxvalueW:write(maxvalue)
    io.close(maxvalueW)
end

local function writeZeroValue()
    zerovalueW = io.open(fsRoot .."maxvalue.txt","w")
    zerovalueW:write(zero)
    io.close(zerovalueW)
end

local function exitDate()
    saveContent()
    writeBestScore()
    writeMaxValue()
    navigator.finish {
        appID = 0x38, -- lua
        pageId = 0,
    }
end

local function imgaeCreateGame(src,pos)
    local objImage = lvgl.Image(objImageGame.root,{x = pos.x, y = pos.y,src = src,})
    return objImage;
end

-- local function canMoveLeft()
--     for i=1,m do
--         for j=1,n do
--             if board[i][j] ~= 0 and j~= 1 then
--                 if board[i][j-1]==0 or board[i][j-1]== board[i][j] then
--                     return true
--                 else
--                     return false
--                 end
--             end
--         end
--     end
-- end

-- local function canMoveRight()
--     for i=1,m do
--         for j=1,n do
--             if board[i][j] ~= 0 and j~= 4 then
--                 if board[i][j+1]==0 or board[i][j+1]== board[i][j] then
--                     return true
--                 else
--                     return false
--                 end
--             end
--         end
--     end
-- end

-- local function canMoveUp()
--     for i=1,m do
--         for j=1,n do
--             if board[i][j] ~= 0 and i ~= 1 then
--                 if board[i-1][j]==0 or board[i-1][j]== board[i][j] then
--                     return true
--                 else
--                     return false
--                 end
--             end
--         end
--     end
-- end

-- local function canMoveDown()
--     for i=1,m do
--         for j=1,n do
--             if board[i][j] ~= 0 and i ~= 4 then
--                 if board[i+1][j]==0 or board[i+1][j]== board[i][j] then
--                     return true
--                 else
--                     return false
--                 end
--             end
--         end
--     end
-- end

-- local function nomove()
--     printf("666666666666666666666666666666666666666666666666666666666666666",canMoveDown(),canMoveLeft(),canMoveRight(),canMoveUp())
--     if canMoveDown() or canMoveLeft() or canMoveRight() or canMoveUp() then
--         return false
--     else
--         return true
--     end    
-- end


local function canMove()
    for i=1,m do
        for j=1,n do
            if board[i][j]==0 then
                return true
            end
            if (i<m and j<n)
            and (board[i][j]==board[i][j+1]
                or board[i][j]==board[i+1][j]) then
                return true
            end
        end
    end
    return false
    
end

--num is 2 or 4
local function updateOneCell(i,j,num)
    if num ~= 0 then
        numImg = string.format("%d.rle", num)
        printf("updateOneCell",i,j,num)
        cell[((i-1) * 4+ j)]:set{src = imgPath(numImg)};
    else
        cell[((i-1) * 4+ j)]:set{src = imgPath("R67.rle")};
    end

    if num  == 2048 then
        objImageGame.winPic:clear_flag(lvgl.FLAG.HIDDEN)
    end

    -- printf("move state ",nomove(),canMoveDown(),canMoveLeft(),canMoveRight(),canMoveUp())
    -- if zeroSpace ==0 and nomove() == true then
    --     objImageGame.overPic:clear_flag(lvgl.FLAG.HIDDEN)
    -- end
end

local function countMaxValue()
    for i=1,m do
        for j=1,n do
            if board[i][j] > tonumber(maxvalue) then
                maxvalue = board[i][j]
               
            end
        end
    end
end


local function readContent()
    
    gamefiles = io.open(fsRoot .."gameContent.txt","r")
    if not gamefiles then return nil end

    local content = {}
    local line = gamefiles:read()

    io.close(gamefiles)

    for number in string.gmatch(line,"%d+") do
                table.insert(content, tonumber(number))
    end

    local matrix={}
    for i=1,m  do
        matrix[i]= {}
        for j=1,n do
            local index =(i-1)*4 +j
            matrix[i][j] = content[index]
        end
    end

    return matrix
end

local function updateScoreNow()
    printf("updateScoreNow maxvalue is",maxvalue)

    if type(maxvalue) == "string" then
        maxvalue = tonumber(maxvalue)
    end

    score1Img= string.format("score%d.rle", maxvalue)
    if maxvalue>=2 and maxvalue<=8 then
       objImageGame.scoreNow:set{src = imgPath(score1Img),x = 20}
    elseif maxvalue>=16 and maxvalue<=64 then
       objImageGame.scoreNow:set{src = imgPath(score1Img),x = 15}
    elseif maxvalue>=128  then
       objImageGame.scoreNow:set{src = imgPath(score1Img),x = 10}
    end
end 

local function updateHisBest()
    printf("updateHisBest")
    if type(maxvalue) == "string" then
        maxvalue = tonumber(maxvalue)
    end
    
    if maxvalue >= tonumber(historyBest) then
        if maxvalue>=2 and maxvalue<=8 then
           score1Img= string.format("score%d.rle", maxvalue)
           objImageGame.scoreBest:set{src = imgPath(score1Img),x = 150}
        elseif maxvalue>=16 and maxvalue<=64 then
           score1Img= string.format("score%d.rle", maxvalue)
           objImageGame.scoreBest:set{src = imgPath(score1Img),x = 145}
        elseif maxvalue>=128 and maxvalue<=512 then
           score1Img= string.format("score%d.rle", maxvalue)
           objImageGame.scoreBest:set{src = imgPath(score1Img),x = 140}
        elseif maxvalue>=1024 and maxvalue<=8192 then
           score1Img= string.format("score%d.rle", maxvalue)
           objImageGame.scoreBest:set{src = imgPath(score1Img),x = 120}
        else
           score1Img= string.format("score%d.rle", maxvalue)
           objImageGame.scoreBest:set{src = imgPath(score1Img),x = 110}
        end
    end
end


local function readBestValue()
    historyBestR = io.open(fsRoot .."historyBest.txt","r")
    if not historyBestR then return nil end
    historyBest = historyBestR:read()
    printf("-------readData----------",historyBest)
    io.close(historyBestR)

    if type(historyBest) == "string" then
        historyBest = tonumber(historyBest)
    end

    if historyBest == nil then
        historyBest=0
    end

end

local function readMaxValue()
    MaxValueR = io.open(fsRoot .."maxvalue.txt","r")
    if not MaxValueR then return nil end

    maxvalue = MaxValueR:read()
    printf("-------readData----------",maxvalue)
    io.close(MaxValueR)

    if type(maxvalue) == "string" then
        maxvalue = tonumber(maxvalue)
    end

    if maxvalue == nil then
        maxvalue=0
    end
end

local function getRandomZeroPos(board)
    local m = #board
    local n = #board[1]
    local zeros = {}
    for i=1,m do
        for j=1,n do
            if board[i][j]==0 then
                table.insert(zeros,{i=i,j=j})
            end
        end
    end
    zeroSpace= #zeros
    printf("space is 0 num",zeroSpace)

    if #zeros>0 then
        local r = math.random(1,#zeros)
        return zeros[r].i,zeros[r].j
    end

end

local function randomNum(board)
    local i,j = getRandomZeroPos(board)

    if i and j then
        local r = math.random()
        if r<0.9 then
            board[i][j] = 2
        else
            board[i][j] = 4
        end
        updateOneCell(i,j,board[i][j])
        printf("random Num location",i,j)
        return i,j
    end
end

local function resetDate()
    for i=1,m do
        for j=1,n do
            if board[i][j] ~= 0 then
                board[i][j] = 0
                updateOneCell(i, j, board[i][j])
            end
        end
    end

    maxvalue = 0
    score1Img= string.format("score%d.rle", maxvalue)
    objImageGame.scoreNow:set{src = imgPath(score1Img)}
    randomNum(board)
    saveContent()
    writeBestScore()
    writeZeroValue()
    objImageGame.overPic:add_flag(lvgl.FLAG.HIDDEN)
end


local function moveLeft()
    print("==============moveLeft===============")
    local m = #board
    local n = #board[1]
    for i=1,m do
        local line = {}
        --从左到右，把值放入line
        for j=1,n do
            if board[i][j]~=0 then
                table.insert(line,board[i][j])
            end
        end
        --移动至左侧
        local k=#line
        for j=1,n do
            if j<=k then
                board[i][j] = line[j]
                updateOneCell(i,j,board[i][j])
            else
                board[i][j] = 0
                updateOneCell(i,j,board[i][j])
            end
        end
        --相同值合并
        for j=1,k-1 do
            if board[i][j]==board[i][j+1] then
                board[i][j+1] = board[i][j] + board[i][j+1]
                for x=j,n-1 do
                    board[i][x] = board[i][x+1]
                    updateOneCell(i,x,board[i][x])
                end
                board[i][n] = 0
                updateOneCell(i,n,board[i][n])
            end
        end
    end

	if zeroSpace ==0 and canMove() == false then
        objImageGame.overPic:clear_flag(lvgl.FLAG.HIDDEN)
    end

    countMaxValue()
    updateScoreNow()
    updateHisBest()
    writeBestScore()
    -- saveContent()
    randomNum(board)
end


local function moveRight()
    print("==============moveRight==============")
    local m = #board
    local n = #board[1]
    for i=1,m do
        local line = {}

        --从右到左，把值放入line
        for j=n,1,-1 do
            if board[i][j]~=0 then
                table.insert(line,board[i][j])
            end
        end
        --移动至右侧
        local k = #line
        for j=n,1,-1 do
            if n-j+1<=k then
                board[i][j] = line[n-j+1]
                updateOneCell(i,j,board[i][j])
            else

                board[i][j] = 0
                updateOneCell(i,j,board[i][j])
            end
        end
        --相同值合并
        for j=n,n-k+2,-1 do
            if board[i][j]==board[i][j-1] then
                board[i][j-1] = board[i][j] + board[i][j-1]

                for x=j,2,-1 do
                    board[i][x] = board[i][x-1]
                    updateOneCell(i,x,board[i][x])
                end
                board[i][1] = 0
                updateOneCell(i,1,board[i][1])
            end
        end

    end

	if zeroSpace ==0 and canMove() == false then
        objImageGame.overPic:clear_flag(lvgl.FLAG.HIDDEN)
    end

    countMaxValue()
    updateScoreNow()
    updateHisBest()
    writeBestScore()
    -- saveContent()
    randomNum(board)
end

local function moveUp()
    print("===============moveUp================")
    local m = #board
    local n = #board[1]
    for j=1,n do
        local line = {}

        for i=1,m do
            if board[i][j]~=0 then
                table.insert(line,board[i][j])
            end
        end

        local k = #line
        for i=1,m do
            if i<=k then
                board[i][j] = line[i]
                updateOneCell(i,j,board[i][j])
            else
                board[i][j] = 0
                updateOneCell(i,j,board[i][j])
            end
        end

        for i=1,k-1 do
            if board[i][j]==board[i+1][j] then
                board[i+1][j] = board[i][j] + board[i+1][j]
                for x=i,m-1 do
                    board[x][j] = board[x+1][j]
                    updateOneCell(x,j,board[x][j])
                end
                board[m][j] = 0
                updateOneCell(m,j,board[m][j])
            end           
        end
    end

	if zeroSpace ==0 and canMove() == false then
        objImageGame.overPic:clear_flag(lvgl.FLAG.HIDDEN)
    end

    countMaxValue()
    updateScoreNow()
    updateHisBest()
    writeBestScore()
    randomNum(board)
end

local function moveDown()
    print("==============moveDown===============")
    local m = #board
    local n = #board[1]
    for j=1,n do
        local line = {}
        for i=m,1,-1 do
            if board[i][j]~=0 then
                table.insert(line,board[i][j])
            end
        end
        local k = #line
        for i=m,1,-1 do
            if m-i+1<=k then
                board[i][j] = line[m-i+1]
                updateOneCell(i,j,board[i][j])
            else
                board[i][j] = 0
                updateOneCell(i,j,board[i][j])
            end
        end
        for i=m,m-k+2,-1 do
            if board[i][j]==board[i-1][j] then
                board[i-1][j] = board[i][j] + board[i-1][j]
                for x=i,2,-1 do
                    board[x][j] = board[x-1][j]
                    updateOneCell(x,j,board[x][j])
                end
                board[1][j] = 0
                updateOneCell(1,j,board[1][j])
            end
        end
    end

	if zeroSpace ==0 and canMove() == false then
        objImageGame.overPic:clear_flag(lvgl.FLAG.HIDDEN)
    end

    countMaxValue()
    updateScoreNow()
    updateHisBest()
    writeBestScore()
    randomNum(board)
end

local function gesture()
    --上滑
    if ((y2-y1) <-10 and math.abs(y2-y1) > math.abs(x2-x1)) then
        moveUp()
    end

    --下滑
    if ((y2-y1) >10 and math.abs(y2-y1) > math.abs(x2-x1)) then
        moveDown()
    end

    --左滑
    if ((x2-x1) <-10 and math.abs(x2-x1) > math.abs(y2-y1)) then
        moveLeft()
    end

    --右滑
    if ((x2-x1) >10 and math.abs(x2-x1) > math.abs(y2-y1) ) then
        moveRight()
    end
end

local function view_init()
    objImageGame.root = lvgl.Object(nil, {
        outline_width = 0,
        border_width = 0,
        pad_all = 0,
        bg_opa = 0,
        bg_color = 0,
        w = 192,
        h = 490,
    })

    objImageGame.BackBtn = lvgl.Object(objImageGame.root, {
        outline_width = 0,
        border_width = 0,
        pad_all = 0,
        bg_opa = 0,
        bg_color = 0,
        w = 120,
        h = 60,
        x =35,
        y = 11,
    })

    objImageGame.ResetBtn = lvgl.Object(objImageGame.root, {
        outline_width = 0,
        border_width = 0,
        pad_all = 0,
        bg_opa = 0,
        bg_color = 0,
        w = 120,
        h = 60,
        x =37,
        y = 415,
    })

    objImageGame.InfoBtn = lvgl.Object(objImageGame.root, {
        outline_width = 0,
        border_width = 0,
        pad_all = 0,
        bg_opa = 0,
        bg_color = 0,
        w = 30,
        h = 30,
        x = 81,
        y = 382,
    })


    objImageGame.BackBtn:add_flag(lvgl.FLAG.CLICKABLE)
    objImageGame.ResetBtn:add_flag(lvgl.FLAG.CLICKABLE)
    objImageGame.InfoBtn:add_flag(lvgl.FLAG.CLICKABLE)

    objImageGame.BackBtn:onClicked(function ()
        exitDate();
        printf("BackBtn Clicked")
    end)

    objImageGame.ResetBtn:onClicked(function ()
        resetDate();
        printf("ResetBtn Clicked")
    end)

    objImageGame.InfoBtn:onClicked(function ()
        objImageGame.arrowImg:clear_flag(lvgl.FLAG.HIDDEN)
        printf("InfoBtn Clicked")
    end)

    objImageGame.root:onevent(lvgl.EVENT.ALL,function(obj, code)
        local indev = lvgl.indev.get_act()
        if not indev then return end

        if code == lvgl.EVENT.PRESSED then
             x1, y1 = indev:get_point()
            print("presss location x1,y1: ",x1, y1)
        end

        if code == lvgl.EVENT.RELEASED then
            x2, y2 = indev:get_point()
           print("release location x1,y1: ",x2, y2)
           gesture()

       end
    end)

    --bg
    objImageGame.bgImage = imgaeCreateGame(imgPath("bg.rle"),{x = 0, y = 0});
    objImageGame.root:clear_flag(lvgl.FLAG.GESTURE_BUBBLE)

    --读取保存历史最大值
    readBestValue()

    --读取保存当前最大值
    readMaxValue()

    --当前最大
    if tonumber(maxvalue)<=8 then
        objImageGame.scoreNow = imgaeCreateGame(imgPath("score0.rle"),{x = 20, y = 345});
    elseif tonumber(maxvalue)>=16 and tonumber(maxvalue)<=64 then
        objImageGame.scoreNow = imgaeCreateGame(imgPath("score0.rle"),{x = 15, y = 345});
    elseif tonumber(maxvalue)>=128  then
        objImageGame.scoreNow = imgaeCreateGame(imgPath("score0.rle"),{x = 10, y = 345});
    end

    scoreImg= string.format("score%d.rle", maxvalue)
    objImageGame.scoreNow:set{src = imgPath(scoreImg)}


    --历史最高
    if tonumber(historyBest)<=8 then
        objImageGame.scoreBest = imgaeCreateGame(imgPath("score0.rle"),{x = 150, y = 345});
    elseif tonumber(historyBest) >=16 and tonumber(historyBest)<=64 then
        objImageGame.scoreBest = imgaeCreateGame(imgPath("score0.rle"),{x = 145, y = 345});
    elseif tonumber(historyBest) >=128 and tonumber(historyBest)<=512 then
        objImageGame.scoreBest = imgaeCreateGame(imgPath("score0.rle"),{x = 140, y = 345});
    elseif tonumber(historyBest) >=1024 and tonumber(historyBest)<=8192 then
        objImageGame.scoreBest = imgaeCreateGame(imgPath("score0.rle"),{x = 120, y = 345});
    else
        printf("historyBest value is ",historyBest)
    end

    scoreHisImg= string.format("score%d.rle", historyBest)
    objImageGame.scoreBest:set{src = imgPath(scoreHisImg)}

    return objImageGame;
end


local function getPosLeft(i, j) 
    return 6 + (j-1) * 46;
end

local function getPosTop(i,j)
    return 126 + (i-1) * 46;
end


local function dataInit()

        for i=1,m do
            if not board[i] then
                board[i] = {}
            end
            for j=1,n do
                board[i][j] = 0;
                cell[(i-1) * 4 + j] = imgaeCreateGame(imgPath("R67.rle"),{x = getPosLeft(i, j), y = getPosTop(i, j)});
            end
        end

   board = readContent();
   if #board >1 then
        for i=1,m do
            for j=1,n do
                updateOneCell(i,j,board[i][j])
            end
        end
    end

    for i=1,m do
        if not added[i] then
            added[i] = {}
        end
        for j=1,n do
            added[i][j] = 0;
        end
    end

     --箭头
     objImageGame.arrowImg = imgaeCreateGame(imgPath("arrow.rle"),{x = 5, y = 118});
     objImageGame.arrowImg:add_flag(lvgl.FLAG.CLICKABLE)
     objImageGame.arrowImg:add_flag(lvgl.FLAG.HIDDEN)

     objImageGame.arrowImg:onClicked(function ()
        objImageGame.arrowImg:add_flag(lvgl.FLAG.HIDDEN)
        printf("arrow Btn Clicked")
    end)

    --you win
    objImageGame.winPic = imgaeCreateGame(imgPath("win.rle"),{x = 5, y = 121});
    objImageGame.winPic:add_flag(lvgl.FLAG.HIDDEN)

    --game over
    objImageGame.overPic = imgaeCreateGame(imgPath("over.rle"),{x = 5, y = 200});
    objImageGame.overPic:add_flag(lvgl.FLAG.HIDDEN)
    
    if canMove() == false then
        objImageGame.overPic:clear_flag(lvgl.FLAG.HIDDEN)
    end

    if #board ==0 then
        randomNum(board)
    end
    
end

local function onCreateGame()
    printf("lvgl game start")
    view_init();
    dataInit();

end

onCreateGame()