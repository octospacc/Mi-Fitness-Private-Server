local lvgl = require("lvgl")

local DEBUG_ENABLE = false
local printf = DEBUG_ENABLE and print or function(...)
end

root = lvgl.Object(nil, {
    outline_width = 0,
    border_width = 0,
    pad_all = 0,
    bg_opa = 0,
    bg_color = 0,
    w = 192,
    h = 490,
})

local fsRoot = SCRIPT_PATH
function imgPath(src)
    return fsRoot .. src
end

local screenW = 192
local screenH = 490
local Velocity = 200/600 -- 球的移动速度, 600ms移动200像素
-- local Velocity = 200/6000 -- 测试，放慢速度
local Dashed_Circle = {x=96, y=344, r=56} -- 发球区域的圆
local R_Ball = 24 --足球的半径24
local Offset_Dashed = 15 -- 球在发球区域的最大偏移
local Goal_Height = 107 --球门高度

local objImageGame = {}
local mBall -- 足球
local mGoal --球门
local mGame -- 一局游戏，包括3小局
local mStageOverTip -- 一小局结束，提示页面
local mGameOverTip -- 游戏结束，提示页面
local mAnimTimer = 0 -- 动画定时器

local mAnimOffset = 0
local mAnimValue = 0
local mAnimStartValue = 0
local mAnimEndValue = 0
local mAnimType = 0

-- 求最接近的整数
local function round(num)
    return math.floor(num + 0.5)
end

-- 计算两点直线的斜率和截距
local function getLineSlopeIntercept(p1, p2)
    if p1.x == p2.x then
        printf("该直线垂直,斜率无穷大.")
        return nil
    end

    local slope = (p2.y - p1.y) / (p2.x - p1.x)
    local intercept = p1.y - slope * p1.x
    return slope, intercept
end

-- 获取圆上的点，已知x坐标，求y坐标，会有两个点。cx cy圆心坐标
local function getCirclePoints(cx, cy, r, x)
    if (x < (cx -r)) or (x > (cx + r)) then
        printf("fail, x坐标不在圆的范围内")
        return nil
    end

    local b = math.sqrt(r^2 - (x - cx)^2)
    local y1 = cy - b
    local y2 = cy + b
    return x, y1, x, y2
end

-- 计算圆与直线的交点
local function getCircleLineIntersections(circle, p1, p2)
    local a = circle.center.x
    local b = circle.center.y
    local r = circle.radius

    local slope, intercept = getLineSlopeIntercept(p1, p2)
    if slope == nil then
        local x1,y1,x2,y2 = getCirclePoints(a, b, r, p1.x)
        return {x = x1,y = y1},{x = x2,y = y2}
    end

    local m = slope
    local c = intercept

    local A = 1+m*m
    local B = 2*m*(c-b)-2*a
    local C = a*a+(c-b)*(c-b)-r*r

    local discriminant = B*B - 4*A*C
    if discriminant < 0 then
        return nil,nil
    else
        local x1 = (-B + math.sqrt(discriminant))/(2*A)
        local x2 = (-B - math.sqrt(discriminant))/(2*A)
        local y1 = m*x1 + c
        local y2 = m*x2 + c
        return {x = x1,y = y1},{x = x2,y = y2}
    end
end

-- 圆的方程表示为 (x - a)^2 + (y - b)^2 = r^2，其中(a, b)是圆的中心，r是圆的半径。
-- 检查点(x, y)是否在圆内的函数
local function isPointInCircle(x, y, a, b, r)
    local dx = x - a
    local dy = y - b
    return dx * dx + dy * dy <= r * r
end

-- 获取球移动的方向,点1是起步点,点2是球移动的方向,x,y坐标是+1还是-1，平行线和垂直线分别为y+0,x+0
local function getDirection(x1,y1,x2,y2)
    printf("计算方向点:开始", x1,y1)
    printf("计算方向点:结束", x2,y2)
    if x1 == x2 and y1 == y2 then
        printf("移动方向计算失败,两个点相同.")
        return 0, 0
    end
    -- 垂直线条
    if x1 == x2 and y1 ~= y2 then
        local yDiff = y1 - y2
        local yABS =  math.abs(yDiff)
        local yDir = -(yDiff/yABS)
        return 0, yDir
    end
    -- 平行线条
    if y1 == y2 and x1 ~= x2 then
        local xDiff = x1 - x2
        local xABS =  math.abs(xDiff)
        local xDir = -(xDiff/xABS)
        return xDir, 0
    end

    local xDiff = x1 - x2
    local xABS =  math.abs(xDiff)
    local yDiff = y1 - y2
    local yABS =  math.abs(yDiff)
    -- 移动方向，x轴增加还是减少
    local xDir = -(xDiff/xABS)
    local yDir = -(yDiff/yABS)
    return xDir,yDir
end

-- 获取两个点的距离
local function getDistance(x1, y1, x2, y2)
    return math.sqrt((x2 - x1) ^ 2 + (y2 - y1) ^ 2)
end

-- 根据已知两点的直线，计算其他点的坐标，已知x坐标，计算y坐标
local function getPointYInLine(x1,y1,x2,y2,xNew)
    if x1 == x2 then
        printf("无法计算，垂直线")
        return nil
    end
    local slope = (y2 - y1) / (x2 - x1)
    local y3 = slope * (xNew - x1) + y1
    return y3
end

-- 根据已知两点的直线，计算其他点的坐标，已知y坐标，计算x坐标
local function getPointXInLine(x1,y1,x2,y2,yNew)
    if y1 == y2 then
        printf("无法计算，平行线")
        return nil
    end

    if x1 == x2 then
        return x1
    end

    local slope = (y2 - y1) / (x2 - x1)
    local x3 = (yNew-y1)/slope + x1
    return x3
end

-- 获取两条直线的交点
local function getLineIntersection(x1,y1,x2,y2,x3,y3,x4,y4)
    if x1 == x2 and x3 == x4 then
        printf("两条直线都是垂直线条，没交点")
        return nil,nil
    end

    if x1 == x2 then
        -- printf("第1条直线是垂直的线条, 交点x坐标确定")
        local y= getPointYInLine(x3,y3,x4,y4,x1)
        return x1,y
    elseif x3 == x4 then
        -- printf("第2条直线是垂直的线条, 交点x坐标确定")
        local y= getPointYInLine(x1,y1,x2,y2,x3)
        return x3,y
    end

    local m1 = (y2 - y1) / (x2 - x1)
    local b1 = y1 - m1 * x1
    local m2 = (y4 - y3) / (x4 - x3)
    local b2 = y3 - m2 * x3
    if m1 == m2 then
        printf("两条直线平行了，没有交点")
        return nil,nil
    end

    local x = (b2 - b1) / (m1 - m2)
    local y = m1 * (b2 - b1) / (m1 - m2) + b1
    return x, y
end

-- 轨迹直线和上边1的交点，
local function getIntersectionSide1(startX,startY,nextX,nextY,xDir,yDir)
    -- 上半圆按照球的半径缩小一圈，使球刚好接触内边
    local circle = {center = {x = 96, y = 96}, radius = (96 - R_Ball)}
    -- 默认有两个交点
    local x1,y1,x2,y2 = nil,nil,nil,nil
    if startX == nextX then
        -- 如果是垂直的线条，x轴是固定的，直接求圆上x坐标对应的两个点
        x1,y1,x2,y2= getCirclePoints(circle.center.x,circle.center.y,circle.radius,startX)
        if x1 == nil or x2 == nil then
            return nil
        end
    else
        local p1 = {x = startX, y = startY}
        local p2 = {x = nextX, y = nextY}
        local point1,point2 = getCircleLineIntersections(circle, p1, p2)
        if point1 == nil or point2 == nil then
            printf("轨迹与边1无交点")
            return nil
        end
        x1 = point1.x
        y1 = point1.y
        x2 = point2.x
        y2 = point2.y

        -- printf("轨迹与上边1的交点1:", x1, y1)
        -- printf("轨迹与上边1的交点2:", x2, y2)
    end

    if y1 <= 96 and y2 <= 96 then
        -- 如果y都小于96，则使用轨迹方向确定交点，
        if xDir < 0 then
            if x1 < x2 then
                return x1,y2
            else
                return x2,y2
            end
        else
            if x1 < x2 then
                return x2,y2
            else
                return x1,y1
            end
        end
    end
    if y1 < 96 and y2 > 96 then
        return x1, y1
    end
    if y1 > 96 and y2 < 96 then
        return x2, y2
    end
    if y1 > 96 and y2 > 96 then
        return nil
    end
    printf("轨迹与上边1的交点无法确定")
end

-- 轨迹直线和下边2的交点，
local function getIntersectionSide2(startX,startY,nextX,nextY,xDir,yDir)
    -- 下半圆按照球的半径缩小一圈，使球刚好接触内边
    local circle = {center = {x = 96, y = 394}, radius = (96 - R_Ball)}
    -- 默认有两个交点
    local x1,y1,x2,y2 = nil,nil,nil,nil
    if startX == nextX then
        -- 如果是垂直的线条，x轴是固定的，直接求圆上x坐标对应的两个点
        x1,y1,x2,y2= getCirclePoints(circle.center.x,circle.center.y,circle.radius,startX)
        if x1 == nil or x2 == nil then
            return nil
        end
    else
        local p1 = {x = startX, y = startY}
        local p2 = {x = nextX, y = nextY}
        local point1,point2 = getCircleLineIntersections(circle, p1, p2)
        if point1 == nil or point2 == nil then
            printf("轨迹与边2无交点")
            return nil
        end
        x1 = point1.x
        y1 = point1.y
        x2 = point2.x
        y2 = point2.y
    end

    if y1 >= 394 and y2 >= 394 then
        -- 如果y都大于394，则使用轨迹方向确定交点，
        if xDir < 0 then
            if x1 < x2 then
                return x1,y2
            else
                return x2,y2
            end
        else
            if x1 < x2 then
                return x2,y2
            else
                return x1,y1
            end
        end
    end
    if y1 > 394 and y2 < 394 then
        return x1, y1
    end
    if y1 < 394 and y2 > 394 then
        return x2, y2
    end
    if y1 < 394 and y2 < 394 then
        return nil
    end
end

-- 轨迹直线和边3的交点
local function getIntersectionSide3(startX,startY,nextX,nextY,xDir,yDir)
    -- 左边3向右移动球半径距离
    local x,y = getLineIntersection(startX,startY,nextX,nextY,R_Ball,96,R_Ball,394)
    printf("轨迹与左边3的交点:", x, y)
    if x == nil or y == nil then
        return nil
    end

    if y < 96 or y > 394 then
        printf("交点超过边3范围")
        return nil
    end

    return x,y
end

-- 轨迹直线和边4的交点
local function getIntersectionSide4(startX,startY,nextX,nextY,xDir,yDir)
    -- 左边4向左移动球半径距离
    local x,y = getLineIntersection(startX,startY,nextX,nextY,(screenW-R_Ball),96,(screenW-R_Ball),394)
    printf("轨迹与左边4的交点:", x, y)
    if x == nil or y == nil then
        return nil
    end

    if y < 96 or y > 394 then
        printf("交点超过边4范围")
        return nil
    end

    return x,y
end


-- 计算碰撞点，用移动方向配合计算，
local function getCollidedPoint(startX,startY,nextX,nextY)
    local xDir,yDir = getDirection(startX,startY,nextX,nextY)
    printf("移动方向：", xDir, yDir)
    local inter1X,inter1Y = getIntersectionSide1(startX,startY,nextX,nextY,xDir,yDir)
    local inter2X,inter2Y = getIntersectionSide2(startX,startY,nextX,nextY,xDir,yDir)
    local inter3X,inter3Y = getIntersectionSide3(startX,startY,nextX,nextY,xDir,yDir)
    local inter4X,inter4Y = getIntersectionSide4(startX,startY,nextX,nextY,xDir,yDir)
    printf("计算边1碰撞点: ", inter1X,inter1Y)
    printf("计算边2碰撞点: ", inter2X,inter2Y)
    printf("计算边3碰撞点: ", inter3X,inter3Y)
    printf("计算边4碰撞点: ", inter4X,inter4Y)

    -- 和哪个边碰撞？
    if yDir < 0 and xDir < 0 then
        -- 上左，1，3
        if inter1X == nil and inter3X == nil then
            -- printf("计算碰撞点失败, 1,3")
            if inter2X ~= nil then
                return 2, inter2X,inter2Y
            end
            return nil
        elseif inter1X == nil then
            return 3, inter3X, inter3Y
        else
            return 1, inter1X, inter1Y
        end
    elseif yDir < 0 and xDir > 0 then
        -- 上右,1,4
        if inter1X == nil and inter4X == nil then
            -- printf("计算碰撞点失败, 1,4")
            if inter2X ~=nil then
                return 2, inter2X, inter2Y
            end
            return nil
        elseif inter1X == nil then
            return 4, inter4X, inter4Y
        else
            return 1, inter1X, inter1Y
        end
    elseif yDir > 0 and xDir < 0 then
        -- 下左，2，3
        if inter2X == nil and inter3X == nil then
            -- printf("计算碰撞点失败, 2,3")
            if inter1X ~= nil then
                return 1, inter1X, inter1Y
            end
            return nil
        elseif inter2X == nil then
            return 3, inter3X, inter3Y
        else
            return 2, inter2X, inter2Y
        end
    elseif yDir > 0 and xDir > 0 then
        -- 下右，2，4
        if inter2X == nil and inter4X == nil then
            -- printf("计算碰撞点失败, 2,4")
            if inter1X ~= nil then
                return 1, inter1X, inter1Y
            end
            return nil
        elseif inter4X == nil then
            return 2, inter2X, inter2Y
        else
            return 4, inter4X, inter4Y
        end
    elseif yDir == 0 and xDir < 0 then
        if startY < 96 then
            -- 上，1
            return 1, inter1X, inter1Y
        elseif startY > 394 then
            -- 下，2
            return 2, inter2X, inter2Y
        else
            -- 左，3
            return 3, inter3X, inter3Y
        end
    elseif yDir == 0 and xDir > 0 then
        if startY < 96 then
            -- 上，1
            return 1, inter1X, inter1Y
        elseif startY > 394 then
            -- 下，2
            return 2, inter2X, inter2Y
        else
            -- 右，4
            return 4, inter4X, inter4Y
        end
    elseif xDir == 0 and yDir < 0 then
        -- 上，1
        return 1, inter1X, inter1Y
    elseif xDir == 0 and yDir > 0 then
        -- 下，2
        return 2, inter2X, inter2Y
    end
end

-- 计算已知某点，相对于某直线的对称点
local function calcSymPoint(x1, y1, k, b)
    printf("哪个点的对称点：", x1, y1)
    local p, q
    local A = k
    local B = -1
    local C = b
    local a = x1
    b = y1
    p = a - (2 * A * (A * a + B * b + C)) / (A * A + B * B);
    q = b - (2 * B * (A * a + B * b + C)) / (A * A + B * B);
    printf("计算对称点--->", p,q)
    return p,q
end

-- 移动动画
local function moveAnim2(startX,startY,endX,endY)
    -- x、y哪个绝对值大，用哪个进行位移计算，这样能保证动画细腻
    local diffX = math.abs(endX - startX)
    local diffY = math.abs(endY - startY)
    if round(startX) == round(endX) then
        mAnimType = 1 -- 垂直
        mAnimStartValue = startY
        mAnimEndValue = endY
    elseif round(startY) == round(endY) then
        mAnimType = 2 --平行
        mAnimStartValue = startX
        mAnimEndValue = endX
    elseif diffY > diffX then
        mAnimType = 3 -- y坐标
        mAnimStartValue = startY
        mAnimEndValue = endY
    else
        mAnimType = 4 -- x坐标
        mAnimStartValue = startX
        mAnimEndValue = endX
    end

    local distance = getDistance(startX,startY,endX,endY)
    -- 计算每帧的偏移量，帧率为1000/?
    mAnimOffset = (mAnimEndValue - mAnimStartValue) * (1000 / 30) * (Velocity / distance)
    mAnimValue = mAnimStartValue
    -- timer中要用全局变量，或者可以优化下封装成对象处理。
    if(mAnimTimer == 0)then
        mAnimTimer = lvgl.Timer {
            period = 1000 / 25,
            cb = function(t)
                mAnimValue = mAnimValue + mAnimOffset
                if mAnimType == 1 then
                    -- value是y坐标，x坐标固定
                    mBall:move(mBall.startX,mAnimValue)
                    printf("垂直移动")
                elseif mAnimType == 2 then
                    mBall:move(mAnimValue,mBall.startY)
                    printf("平行移动")
                elseif mAnimType == 3 then
                    local dy = mAnimValue
                    local dx = getPointXInLine(mBall.startX,mBall.startY,mBall.endX,mBall.endY,dy)
                    if dx ~= nil then
                        mBall:move(dx,dy)
                    end
                else
                    local dx = mAnimValue
                    local dy = getPointYInLine(mBall.startX,mBall.startY,mBall.endX,mBall.endY,dx)
                    if dy ~= nil then
                        mBall:move(dx,dy)
                    end
                end
                -- 误差在一个半个偏移单位内
                if math.abs(mAnimEndValue-mAnimValue) < math.abs(mAnimOffset/2) then
                    printf("anim done ------> value:", mAnimValue)
                    mBall.anim = nil
                    -- 上一条轨迹的终点，也就是碰撞点，就是下一条轨迹的起点，
                    mBall:collide(mBall.endX,mBall.endY)
                    return
                end

            end
        }
    end

end

-- 位移动画，平行线只能移动x轴，垂直线条只能移动y轴
-- local function moveAnim(startX,startY,endX,endY)
--     local type = 1
--     local startValue = startX
--     local endValue = endX
--     -- x、y哪个绝对值大，用哪个进行位移计算，这样能保证动画细腻
--     local diffX = math.abs(endX - startX)
--     local diffY = math.abs(endY - startY)
--     if round(startX) == round(endX) then
--         type = 1 -- 垂直
--         startValue = startY
--         endValue = endY
--     elseif round(startY) == round(endY) then
--         type = 2 --平行
--         startValue = startX
--         endValue = endX
--     elseif diffY > diffX then
--         type = 3 -- y坐标
--         startValue = startY
--         endValue = endY
--     else
--         type = 4 -- x坐标
--         startValue = startX
--         endValue = endX
--     end

--     local duration = getDistance(startX,startY,endX,endY)/Velocity

--     mBall.anim = mBall.widget:Anim {
--         run = true,
--         start_value = startValue,
--         end_value = endValue,
--         duration = duration,
--         repeat_count = 1,
--         path = "linear",
--         exec_cb = function(obj, value)
--             if type == 1 then
--                 -- value是y坐标，x坐标固定
--                 mBall:move(startX,value)
--                 printf("垂直移动")
--             elseif type == 2 then
--                 mBall:move(value,startY)
--                 printf("平行移动")
--             elseif type == 3 then
--                 local dy = value
--                 local dx = getPointXInLine(startX,startY,endX,endY,dy)
--                 if dx ~= nil then
--                     mBall:move(dx,dy)
--                 end
--             else
--                 local dx = value
--                 local dy = getPointYInLine(startX,startY,endX,endY,dx)
--                 if dy ~= nil then
--                     mBall:move(dx,dy)
--                 end
--             end
--         end,
--         done_cb = function (anim, obj)
--             print("---------------->anim done.: ", anim, "obj:", obj)
--             anim:delete()
--             mBall.anim = nil
--             -- 上一条轨迹的终点，也就是碰撞点，就是下一条轨迹的起点，
--             mBall:collide(endX, endY)
--         end
--     }
-- end

-- 计算下一个轨迹
local function getNextTrack(lastStartX, lastStartY, currentX, currentY)
    if mBall.side == 1 then

        if currentX == 96 then
            -- 如果当前点和上圆中心点在垂直线上，斜率是没有的，对称点y轴坐标是一样的，必然经过的点是(96,y),
            -- (lastStartX, lastStartY)-->(96,lastStartY)-->(?,lastStartY)
            -- 等比计算：96 - lastStartX = x - 96
            -- x = screenW - lastStartX
            return (screenW - lastStartX), lastStartY
        end

        local slope, intercept = getLineSlopeIntercept({x = 96, y = 96}, {x = currentX, y = currentY})
        local p,q= calcSymPoint(lastStartX,lastStartY,slope,intercept)
        return p,q
    elseif mBall.side == 2 then
        if currentX == 96 then
            return (screenW - lastStartX), lastStartY
        end
        local slope, intercept = getLineSlopeIntercept({x = 96, y = 394}, {x = currentX, y = currentY})
        local p,q= calcSymPoint(lastStartX,lastStartY,slope,intercept)
        return p,q
    else
        -- 左边，右边，一样
        local slope, intercept = getLineSlopeIntercept({x = currentX, y = currentY}, {x = 96, y = currentY})
        local p,q= calcSymPoint(lastStartX,lastStartY,slope,intercept)
        return p,q
    end

end


-- 创建足球对象，这个是移动的球。
local function BallImage(parent)
    local img = {}
    img.widget = lvgl.Image(parent,{x = 72, y = 320,
        src=imgPath("/shoot/bball.rle")})
    -- 当前所在的位置坐标
    img.x = nil
    img.y = nil
    -- 当前所在轨迹的起始点
    img.startX = nil
    img.startY = nil
    -- 上次轨迹的起始点
    img.lastStartX = nil
    img.lastStartY = nil
    -- 当前所在轨迹的终点
    img.endX = nil
    img.endY = nil
    -- 碰撞次数
    img.reboundCount = 0
    -- 是否激活了移动
    img.isActive = false
    -- 是否正在移动
    img.isMoving = false
    -- 球要和哪个边碰撞
    img.side = nil

    -- 准备，球回到发球点
    function img:ready()
        img.widget:set({
            x = 72,
            y = 320,
        })
    end

    -- 移动
    function img:move(mx,my)
        img.widget:set({
            x = mx - R_Ball,
            y = my - R_Ball,
        })
        img.x = mx
        img.y = my
    end

    -- 保存上一条轨迹的起点,用于计算下个轨迹的对称点
    function img:saveLastStart(startX, startY)
        img.lastStartX = startX
        img.lastStartY = startY
    end

    -- 射球
    function img:shoot(nextX, nextY)
        img.startX = img.x
        img.startY = img.y
        printf("调用射击, shoot---->方向：",nextX, nextY)
        -- 移动方向
        local side, x, y = getCollidedPoint(round(img.startX),round(img.startY),round(nextX),round(nextY))
        if side == nil or x == nil or y == nil then
            printf("异常，无碰撞点")
            return
        end
        printf("计算终点：",side, x, y)
        img.endX = round(x)
        img.endY = round(y)
        -- 开启位移动画
        moveAnim2(img.startX,img.startY,img.endX,img.endY)
        img.side = side
    end

    -- 碰撞
    function img:collide(colX, colY)
        printf("调用碰撞, collide---->起始点：",colX, colY)
        img:saveLastStart(img.startX, img.startY)
        -- 是否进球
        local isGoal= mGoal:checkGoal(colX,colY)
        if isGoal then
            img.reboundCount = 0
            img.isMoving = false
            mGame:stageOver(true)
            return
        end
        -- 是否超过碰撞次数
        if img.reboundCount >= 9 then
            printf("超过10次碰撞")
            img.reboundCount = 0
            img.isMoving = false
            mGame:stageOver(false)
            return
        end
        img.reboundCount = img.reboundCount + 1
        -- 计算对称点后再射击, 
        local nextX, nextY = getNextTrack(img.lastStartX,img.lastStartY,img.x,img.y)
        img:shoot(nextX,nextY)
    end

    return img
end

-- 激活发球，当手指按下时。
local function activeShoot(x_indev,y_indev)
    if isPointInCircle(x_indev,y_indev,Dashed_Circle.x,Dashed_Circle.y,Dashed_Circle.r) then
        -- 计算是否在发球圈内，如果在，才能激活球的移动
        printf("激活了球的移动")
        mBall.isActive = true
        -- 取消事件冒泡，禁止右滑退出
        objImageGame.supermanRoot:clear_flag(lvgl.FLAG.GESTURE_BUBBLE)
    end
end

-- 准备发球，当手指移动时。
local function prepareShoot(x_indev,y_indev)
    -- 判断是否在发球圈内,缩小一部分，允许球出来一点
    if isPointInCircle(x_indev,y_indev,Dashed_Circle.x,
            Dashed_Circle.y,(Dashed_Circle.r - Offset_Dashed)) then
        -- 在发球区域内直接移动球
        mBall:move(x_indev,y_indev)
        mBall:saveLastStart(x_indev,y_indev)
    else
        -- 不在发球区内，移动球到发球区边界
        -- 计算按压点和圆心的直线与大圆圈的交叉点
        local circle = {center = {x = Dashed_Circle.x, y = Dashed_Circle.y},
            radius = (Dashed_Circle.r - Offset_Dashed)}
        local p1 = {x = Dashed_Circle.x, y = Dashed_Circle.y}
        local p2 = {x = x_indev, y = y_indev}
        local point1,point2 = getCircleLineIntersections(circle, p1, p2)
        if point1 and point2 then
            local dist1 = getDistance(point1.x, point1.y, x_indev, y_indev)
            local dist2 = getDistance(point2.x, point2.y, x_indev, y_indev)
            if dist1 < dist2 then
                -- 移动球
                mBall:move(point1.x,point1.y)
                mBall:saveLastStart(point1.x,point1.y)
            else
                mBall:move(point2.x,point2.y)
                mBall:saveLastStart(point2.x,point2.y)
            end
        end
    end
end

-- 球门 GoalImage
local function GoalImage(parent)
    local img = {}
    img.widgetLeft = lvgl.Image(parent,{x = 0, y = 96,
        src=imgPath("/shoot/lgoal.rle")})
    img.widgetLeft:add_flag(lvgl.FLAG.HIDDEN)

    img.widgetRight = lvgl.Image(parent,{x = 161, y = 96,
        src=imgPath("/shoot/rgoal.rle")})
    img.widgetRight:add_flag(lvgl.FLAG.HIDDEN)

    -- 球门的方向，左0，右1，默认0
    img.direction = 0
    -- 球的y坐标, 默认96
    img.y = 96

    -- 放置球的位置
    function img:ready()
        -- 随机方向
        img.direction = math.random(0, 1)
        printf("球门方向:", img.direction)
        -- 随机y轴
        img.y = math.random(96, 287)
        printf("球门y坐标:", img.y)

        if img.direction == 0 then
            img.widgetLeft:clear_flag(lvgl.FLAG.HIDDEN)
            img.widgetRight:add_flag(lvgl.FLAG.HIDDEN)
            img.widgetLeft:set({
                y = img.y
            })
        else
            img.widgetLeft:add_flag(lvgl.FLAG.HIDDEN)
            img.widgetRight:clear_flag(lvgl.FLAG.HIDDEN)
            img.widgetRight:set({
                y = img.y
            })
        end
    end

    -- 检查球是否进入球门
    function img:checkGoal(ballX, ballY)
        printf("是否进球？", img.y, ballY, (img.y + Goal_Height))
        if ballY >= img.y and ballY <= (img.y + Goal_Height) then
            if img.direction == 0  and ballX < 96 then
                return true
            elseif img.direction == 1 and ballX > 96 then
                return true
            end
        end
        return false
    end

    return img
end

-- 球的数量，游戏内
local function BallNumberImage(parent)
    local img = {}
    img.widgetBall1 = lvgl.Image(parent,{x = 50, y = 450,
        src=imgPath("/shoot/sball.rle")})
    img.widgetBall2 = lvgl.Image(parent,{x = 85, y = 456,
        src=imgPath("/shoot/sball.rle")})
    img.widgetBall3 = lvgl.Image(parent,{x = 120, y = 450,
        src=imgPath("/shoot/sball.rle")})
    img.widgetEclipse = lvgl.Image(parent,{x = 116, y = 446,
        src=imgPath("/shoot/eclipse.rle")})
    -- sball_gray.rle
    img.number = 3 -- 默认3个球的机会

    -- 更新球个数图片
    local function updateSballView()
        if img.number == 3 then
            img.widgetEclipse:set({
                x = 116,
                y = 446
            })
            img.widgetBall1:set({src=imgPath("/shoot/sball.rle")})
            img.widgetBall2:set({src=imgPath("/shoot/sball.rle")})
            img.widgetBall3:set({src=imgPath("/shoot/sball.rle")})
        elseif img.number == 2 then
            img.widgetEclipse:set({
                x = 81,
                y = 452
            })
            img.widgetBall1:set({src=imgPath("/shoot/sball.rle")})
            img.widgetBall2:set({src=imgPath("/shoot/sball.rle")})
            img.widgetBall3:set({src=imgPath("/shoot/sball_gray.rle")})
        elseif img.number == 1 then
            img.widgetEclipse:set({
                x = 46,
                y = 446
            })
            img.widgetBall1:set({src=imgPath("/shoot/sball.rle")})
            img.widgetBall2:set({src=imgPath("/shoot/sball_gray.rle")})
            img.widgetBall3:set({src=imgPath("/shoot/sball_gray.rle")})
        else
            printf("球次数消耗完了")
        end
    end

    -- 准备
    function img:ready()
        img.number = 3
        updateSballView()
    end

    -- 扣除机会，失败时调用。如果成功，不需要调用
    function img:deduct()
        img.number = img.number -1
        updateSballView()
        return img.number
    end

    return img
end

local function writeData(score)
    local sfile = io.open(fsRoot .."historyData.txt","w")
    if sfile then
        sfile:write(score)
        io.close(sfile)
        printf("-------writeData----------",score)
    end
end

local function readData()
    local sfile = io.open(fsRoot .."historyData.txt","r")
    if sfile then
        local score = sfile:read()
        printf("-------readData----------",score)
        io.close(sfile)
        if score==nil then
            score = 0
        end
        return tonumber(score)
    end
    return 0
end

-- 一局游戏，记录 开始，结束，机会次数等数据
local function Game(parent)
    local game = {}
    -- 球的次数展示
    game.widgetNum = BallNumberImage(parent)
    -- 当前得分，初始是0分
    game.score = 0

    -- 准备游戏，初始化数据，布局
    function game:ready()
        game.score = 0
        mBall:ready()
        mGoal:ready()
        game.widgetNum:ready()
    end

    -- 游戏结束
    function game:gameOver()
        printf("游戏结束！！！")
        -- 读取历史记录，todo 是否时新记录,如果是新记录，保存记录
        local historyScore = readData()
        if game.score > historyScore then
            -- 新纪录
            mGameOverTip:showTip(game.score, true)
            -- 保存新记录
            writeData(game.score)
        else
            -- 无新纪录
            mGameOverTip:showTip(game.score, false)
        end
    end

    -- 一局结束
    function game:stageOver(isSuccess)
        if mAnimTimer ~= 0 then
            mAnimTimer:delete()
            mAnimTimer=0
        end
        mBall:ready()
        mGoal:ready()
        -- 取消事件冒泡，禁止右滑退出
        objImageGame.supermanRoot:add_flag(lvgl.FLAG.GESTURE_BUBBLE)
        if isSuccess then
            game.score = game.score + 1
            printf("得分：+1, total:",game.score)
            if game.score >= 999 then
                -- 分数大于999游戏结束
                game.score = 999
                game:gameOver()
                return
            end
            mStageOverTip:show(true, game.score)
        else
            local num = game.widgetNum:deduct()
            if num == 0 then
                -- 游戏结束
                game:gameOver()
            else
                printf("失去一个球")
                mStageOverTip:show(false, game.score)
            end
        end
    end

    return game
end

local function StageOverTip(parent)
    local tip = {}
    tip.bg = lvgl.Object(parent, {
        outline_width = 0,
        border_width = 0,
        pad_all = 0,
        bg_opa = lvgl.OPA(75),
        bg_color = "#030602",
        w = 192,
        h = 490,
    })
    tip.bg:onevent(lvgl.EVENT.CLICKED,function(obj, code)
        tip.bg:add_flag(lvgl.FLAG.HIDDEN)
    end)
    tip.bg:add_flag(lvgl.FLAG.HIDDEN)

    tip.widgetTitle = lvgl.Image(tip.bg,{x = 60, y = 50, src=imgPath("/shoot/score_title.rle")})
    -- 得分，最大值999
    tip.score0 = lvgl.Image(tip.bg,{x = 70, y = 75, src=imgPath("/shoot/score0.rle")})
    tip.score1 = lvgl.Image(tip.bg,{x = 88, y = 75, src=imgPath("/shoot/score0.rle")})
    tip.score2 = lvgl.Image(tip.bg,{x = 106, y = 75, src=imgPath("/shoot/score0.rle")})
    --得分+1
    tip.get_score = lvgl.Image(tip.bg,{x = 63, y = 240, src=imgPath("/shoot/get_score.rle")})
    --减去机会-1
    tip.lose_num = lvgl.Image(tip.bg,{x = 63, y = 240, src=imgPath("/shoot/lose_num.rle")})
    -- goal!
    tip.tip_goal = lvgl.Image(tip.bg,{x = 29, y = 166, src=imgPath("/shoot/tip_goal.rle")})
    -- again!
    tip.tip_again = lvgl.Image(tip.bg,{x = 20, y = 166, src=imgPath("/shoot/tip_again.rle")})


    function tip:show(isSuccess, score)
        tip.bg:clear_flag(lvgl.FLAG.HIDDEN)
        if isSuccess then
            tip.get_score:clear_flag(lvgl.FLAG.HIDDEN)
            tip.lose_num:add_flag(lvgl.FLAG.HIDDEN)
            tip.tip_goal:clear_flag(lvgl.FLAG.HIDDEN)
            tip.tip_again:add_flag(lvgl.FLAG.HIDDEN)
        else
            tip.get_score:add_flag(lvgl.FLAG.HIDDEN)
            tip.lose_num:clear_flag(lvgl.FLAG.HIDDEN)
            tip.tip_goal:add_flag(lvgl.FLAG.HIDDEN)
            tip.tip_again:clear_flag(lvgl.FLAG.HIDDEN)
        end

        tip.score0:set({
            src=imgPath(string.format("/shoot/score%d.rle", (score//100%10)))
        })
        tip.score1:set({
            src=imgPath(string.format("/shoot/score%d.rle", (score//10%10)))
        })
        tip.score2:set({
            src=imgPath(string.format("/shoot/score%d.rle", (score%10)))
        })

    end

    return tip
end

-- 游戏结束，也就是三个球消耗完，
local function GameOverTip(parent)
    local over = {}
    over.bg = lvgl.Object(parent, {
        outline_width = 0,
        border_width = 0,
        pad_all = 0,
        bg_opa = lvgl.OPA(75),
        bg_color = "#030602",
        w = 192,
        h = 490,
    })
    over.bg:add_flag(lvgl.FLAG.HIDDEN)
    over.back = lvgl.Image(over.bg,{x = 36, y = 20, src=imgPath("/shoot/back.rle")})
    over.restart = lvgl.Image(over.bg,{x = 36, y = 410, src=imgPath("/shoot/restart.rle")})
    over.star = lvgl.Image(over.bg,{x = 55, y = 120, src=imgPath("/shoot/star.rle")})
    over.cup = lvgl.Image(over.bg,{x = 48, y = 112, src=imgPath("/shoot/cup.rle")})
    over.gameover = lvgl.Image(over.bg,{x = 25, y = 271, src=imgPath("/shoot/gameover.rle")})
    over.newrecord = lvgl.Image(over.bg,{x = 28, y = 271, src=imgPath("/shoot/newrecord.rle")})
    -- 分数
    over.bScore0 = lvgl.Image(over.bg,{x = 50, y = 210, src=imgPath("/shoot/b0.rle")})
    over.bScore1 = lvgl.Image(over.bg,{x = 80, y = 210, src=imgPath("/shoot/b0.rle")})
    over.bScore2 = lvgl.Image(over.bg,{x = 110, y = 210, src=imgPath("/shoot/b0.rle")})

    over.back:clear_flag(lvgl.FLAG.GESTURE_BUBBLE)
    over.back:add_flag(lvgl.FLAG.CLICKABLE)
    over.back:onevent(lvgl.EVENT.CLICKED,function(obj, code)
        navigator.finish {
            appID = 0x38, -- 退出lua应用
            pageId = 0,
        }
    end)

    over.restart:clear_flag(lvgl.FLAG.GESTURE_BUBBLE)
    over.restart:add_flag(lvgl.FLAG.CLICKABLE)
    over.restart:onevent(lvgl.EVENT.CLICKED,function(obj, code)
        -- 从新开始
        over.bg:add_flag(lvgl.FLAG.HIDDEN)
        -- 初始化游戏
        mGame:ready()
    end)

    -- 游戏结束提示，score分数，isNewRecord是否是新记录
    function over:showTip(score, isNewRecord)
        over.bg:clear_flag(lvgl.FLAG.HIDDEN)
        -- todo 展示分数，
        if score < 10 then
            -- 两边的数字隐藏
            over.bScore0:add_flag(lvgl.FLAG.HIDDEN)
            over.bScore1:clear_flag(lvgl.FLAG.HIDDEN)
            over.bScore2:add_flag(lvgl.FLAG.HIDDEN)
            over.bScore1:set({
                x = 80, y = 210,
                src=imgPath(string.format("/shoot/b%d.rle", score))
            })
        elseif score >= 10 and score < 100 then
            over.bScore0:clear_flag(lvgl.FLAG.HIDDEN)
            over.bScore1:clear_flag(lvgl.FLAG.HIDDEN)
            over.bScore2:add_flag(lvgl.FLAG.HIDDEN)
            over.bScore0:set({
                x = 65, y = 210,
                src=imgPath(string.format("/shoot/b%d.rle", (score//10%10)))
            })
            over.bScore1:set({
                x = 95, y = 210,
                src=imgPath(string.format("/shoot/b%d.rle", (score%10)))
            })
        elseif score >= 100 and score < 1000 then
            over.bScore0:clear_flag(lvgl.FLAG.HIDDEN)
            over.bScore1:clear_flag(lvgl.FLAG.HIDDEN)
            over.bScore2:clear_flag(lvgl.FLAG.HIDDEN)
            over.bScore0:set({
                x = 50, y = 210,
                src=imgPath(string.format("/shoot/b%d.rle", (score//100%10)))
            })
            over.bScore1:set({
                x = 80, y = 210,
                src=imgPath(string.format("/shoot/b%d.rle", (score//10%10)))
            })
            over.bScore2:set({
                x = 110, y = 210,
                src=imgPath(string.format("/shoot/b%d.rle", (score%10)))
            })
        end

        if isNewRecord then
            over.newrecord:clear_flag(lvgl.FLAG.HIDDEN)
            over.cup:clear_flag(lvgl.FLAG.HIDDEN)
            over.gameover:add_flag(lvgl.FLAG.HIDDEN)
            over.star:add_flag(lvgl.FLAG.HIDDEN)
        else
            over.newrecord:add_flag(lvgl.FLAG.HIDDEN)
            over.cup:add_flag(lvgl.FLAG.HIDDEN)
            over.gameover:clear_flag(lvgl.FLAG.HIDDEN)
            over.star:clear_flag(lvgl.FLAG.HIDDEN)
        end
    end

    return over
end


local function supermansonCreate()
    objImageGame.supermanRoot = lvgl.Object(root, {
        outline_width = 0,
        border_width = 0,
        pad_all = 0,
        bg_opa = 0,
        bg_color = 0,
        w = 192,
        h = 490,
    })
    objImageGame.bgImage = lvgl.Image(objImageGame.supermanRoot,
        {x = 0, y = 0,src=imgPath("/shoot/bg.rle")})
    -- readytoast.rle
    objImageGame.readytoast = lvgl.Image(objImageGame.bgImage,
        {x = 0, y = 10,src=imgPath("/shoot/readytoast.rle")})

    mGame = Game(objImageGame.supermanRoot)
    mGoal = GoalImage(objImageGame.supermanRoot)
    mBall = BallImage(objImageGame.supermanRoot)
    mGame:ready()

    -- 一小局结束，展示的提示 stageOver
    mStageOverTip = StageOverTip(objImageGame.supermanRoot)
    mGameOverTip = GameOverTip(objImageGame.supermanRoot)

    -- 监听事件
    objImageGame.supermanRoot:onevent(lvgl.EVENT.ALL,function(obj, code)
        local indev = lvgl.indev.get_act()
        if not indev then return end
        local x_indev, y_indev = indev:get_point()

        if mBall.isMoving then
            printf("不响应，球正在移动")
            return
        end

        -- 手指按下, activeShoot
        if code == lvgl.EVENT.PRESSED then
            activeShoot(x_indev,y_indev)
        end
        -- 手指滑动, prepareShoot
        if (code == lvgl.EVENT.PRESSING) and mBall.isActive then
            prepareShoot(x_indev,y_indev)
        end
        if (code == lvgl.EVENT.RELEASED) and mBall.isActive then
            printf("释放手指，发射球>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
            -- 计算轨迹，
            mBall.isActive = false
            mBall:shoot(Dashed_Circle.x, Dashed_Circle.y)
            mBall.isMoving = true
            objImageGame.readytoast:add_flag(lvgl.FLAG.HIDDEN)
        end

    end)

end

bgEventCB = function (event)
    -- objImageGame.supermanRoot:clear_flag(lvgl.FLAG.HIDDEN)
end

local function onCreate()
    supermansonCreate()
end

onCreate(bgEventCB)
