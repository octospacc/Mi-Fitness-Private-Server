local lvgl = require("lvgl")
local topic = require("topic")
local vibrator = require("vibrator")
root = lvgl.Object(nil, {
    outline_width = 0,
    border_width = 0,
    pad_all = 0,
    bg_opa = 0,
    bg_color = 0,
    w = 192,
    h = 490,
})
objImageGame = {}
timerData = 3
timerfData = 3
tShow = 0
powerData = 0
speedData = 0
timerf = 0
speedrecordData=0
powerrecordData=0
t = 0
sumMax = 0
psumMax = {}
j = 0
flag = 1
-- 元素偏移，相比较于8pro的屏幕
local allOffset = 70
local DEBUG_ENABLE = true
local printf = DEBUG_ENABLE and print or function(...)
end

local function dataRSA(value)
    for i = 1, #value do
        j = j + 1
        local list ={}
        list.x=value[i].x
        list.y=value[i].y
        list.z=value[i].z

        -- todo 
        -- objImageGame.testLabel1:set{
        --     text = list.x
        -- }
        -- objImageGame.testLabel2:set{
        --     text = list.y
        -- }
        -- objImageGame.testLabel3:set{
        --     text = list.z
        -- }

        psumMax[j]=list
        if(sumMax < math.abs(value[i].x))then
            sumMax = math.abs(value[i].x)
            flag = j
        end
        if(sumMax < math.abs(value[i].y))then
            sumMax = math.abs(value[i].y)
            flag = j
        end
        if(sumMax < math.abs(value[i].z))then
            sumMax = math.abs(value[i].z)
            flag = j
        end
    end
end

local function dataAx()
    local G = 0
    local sumG = {}
    local sumAll = 0

    -- todo
    -- objImageGame.testLabel4:set{
    --     text = sumMax
    -- }
    -- 根据当前A+G的传感器调整参数
    if sumMax < 77 then
        G = sumMax / 9.8
    elseif sumMax >= 77 and sumMax < 78.6445 then
        sumG[1] = 1.011*psumMax[j].z/9.8+5.687
        sumG[2] = 1.068*psumMax[j].y/9.8+4.374
        sumG[3] = math.random(15816,16000)/1000
        table.sort(sumG)
        G = sumG[3]
    else
        G = 7.6057*sumMax - 576.5153 + math.random(0,3000)/1000
        if G > 26 then
            G = math.random(26000, 32000) / 1000
        end
    end

    -- if(sumMax > 155)then
    --     sumG[1] = 1.011*psumMax[j].z/9.8+15.687
    --     sumG[2] = 1.068*psumMax[j].y/9.8+14.374
    --     sumG[3] = math.random(15816,16000)/1000
    --     table.sort(sumG)
    --     G = sumG[3]
    -- else
    --     G = sumMax/9.8
    -- end
    printf("-------dataAxflag----------",flag)
    local prevAx = psumMax[flag].x
    local nextAx = 0
    local sign = flag
    if(prevAx>=0)then
        for i = 1, 15 do
            if(flag <= 1)then
                sumAll = 300
                return G, sumAll
            end
            prevAx = psumMax[flag].x
            nextAx = psumMax[flag-1].x
            flag = flag - 1
            if(nextAx>=0 and prevAx<=0)then
                break
            end
        end
    else
        for i = 1, 15 do
            if(flag <= 1)then
                sumAll = 300
                return G, sumAll
            end
            prevAx = psumMax[flag].x
            nextAx = psumMax[flag-1].x
            flag= flag - 1
            if(nextAx<=0 and prevAx>=0)then
                break
            end
        end
    end

    sumAll = (sign - flag) * 40
    return G, sumAll
end

local function screenOFFCb()
    if t then
        printf("screen off, unsubscribe accel")
        t:unsubscribe()
        t = nil
    end
end

local fsRoot = SCRIPT_PATH
function imgPath(src)
    return fsRoot .. src
end

local function writeData()
    printf("-------writeData----------",speedData)
    speedfilesw = io.open(fsRoot .."shistoryData.txt","w")
    speedfilesw:write(speedData)
    io.close(speedfilesw)
    printf("-------writeData----------",powerData)
    powerfilesw = io.open(fsRoot .."phistoryData.txt","w")
    powerfilesw:write(powerData)
    io.close(powerfilesw)
end

local function readData()
    speedfiles = io.open(fsRoot .."shistoryData.txt","r")
    speedrecordData = speedfiles:read()
    printf("-------readData----------",speedrecordData)
    io.close(speedfiles)
    powerfiles = io.open(fsRoot .."phistoryData.txt","r")
    powerrecordData = powerfiles:read()
    printf("-------readData----------",powerrecordData)
    io.close(powerfiles)
    if(speedrecordData==nil or powerrecordData==nil)then
        speedrecordData = 0
        powerrecordData = '0.00'
    end
end

local function recordData()
    readData()
    printf("-------recordData----------",speedrecordData)
    printf("-------recordData----------",powerrecordData)
    local speedDataLen = #tostring(speedrecordData)
    local powerDataLen=#tostring(powerrecordData)
    local numberAnswer = { 0, 0, 0}
    local sigCoorderr = { 0, 0, 0}
    numberAnswer[1] = speedrecordData % 10
    numberAnswer[2] = speedrecordData // 10 % 10
    numberAnswer[3] = speedrecordData // 100 % 10
    if(speedDataLen==3)then
        objImageGame.hspeedOne:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.hspeedTwo:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.hspeedThree:clear_flag(lvgl.FLAG.HIDDEN)
        sigCoorderr[3]=(112-allOffset)
        sigCoorderr[2]=(148-allOffset)
        sigCoorderr[1]=(184-allOffset)
    elseif(speedDataLen==2)then
        objImageGame.hspeedOne:add_flag(lvgl.FLAG.HIDDEN)
        objImageGame.hspeedTwo:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.hspeedThree:clear_flag(lvgl.FLAG.HIDDEN)
        sigCoorderr[2]=(130-allOffset)
        sigCoorderr[1]=(166-allOffset)
    else
        objImageGame.hspeedOne:add_flag(lvgl.FLAG.HIDDEN)
        objImageGame.hspeedTwo:add_flag(lvgl.FLAG.HIDDEN)
        objImageGame.hspeedThree:clear_flag(lvgl.FLAG.HIDDEN)
        sigCoorderr[1]=(148-allOffset)
    end
    rImageOne = string.format("/superman/%d.rle", numberAnswer[3])
    objImageGame.hspeedOne:set{src=imgPath(rImageOne),x=sigCoorderr[3]}
    rImageTwo = string.format("/superman/%d.rle", numberAnswer[2])
    objImageGame.hspeedTwo:set{src=imgPath(rImageTwo),x=sigCoorderr[2]}
    rImageThree = string.format("/superman/%d.rle", numberAnswer[1])
    objImageGame.hspeedThree:set{src=imgPath(rImageThree),x=sigCoorderr[1]}
    if(powerDataLen==5)then
        objImageGame.hdynamicsOne:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.hdynamicsTwo:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.hdynamicsThree:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.hdynamicsFour:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.hdynamics:clear_flag(lvgl.FLAG.HIDDEN)
        dynamicsone = string.sub(powerrecordData,1,1)..".rle"
        dynamicsTwo = string.sub(powerrecordData,2,2)..".rle"
        dynamicsThree = string.sub(powerrecordData,4,4)..".rle"
        dynamicsFour = string.sub(powerrecordData,5,5)..".rle"
        Ones = string.format("/superman/"..dynamicsone)
        objImageGame.hdynamicsOne:set{src=imgPath(Ones),x=(87-allOffset)}
        One = string.format("/superman/"..dynamicsTwo)
        objImageGame.hdynamicsTwo:set{src=imgPath(One),x=(123-allOffset)}
        Two = string.format("/superman/"..dynamicsThree)
        objImageGame.hdynamicsThree:set{src=imgPath(Two),x=(173-allOffset)}
        Three = string.format("/superman/"..dynamicsTwo)
        objImageGame.hdynamicsFour:set{src=imgPath(Three),x=(209-allOffset)}
        objImageGame.hdynamics:set{x=(159-allOffset)}
    else
        objImageGame.hdynamicsOne:add_flag(lvgl.FLAG.HIDDEN)
        objImageGame.hdynamicsTwo:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.hdynamicsThree:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.hdynamicsFour:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.hdynamics:clear_flag(lvgl.FLAG.HIDDEN)
        dynamicsTwo = string.sub(powerrecordData,1,1)..".rle"
        dynamicsThree = string.sub(powerrecordData,3,3)..".rle"
        dynamicsFour = string.sub(powerrecordData,4,4)..".rle"
        One = string.format("/superman/"..dynamicsTwo)
        objImageGame.hdynamicsTwo:set{src=imgPath(One),x=(105-allOffset)}
        Two = string.format("/superman/"..dynamicsThree)
        objImageGame.hdynamicsThree:set{src=imgPath(Two),x=(155-allOffset)}
        Three = string.format("/superman/"..dynamicsFour)
        objImageGame.hdynamicsFour:set{src=imgPath(Three),x=(191-allOffset)}
        objImageGame.hdynamics:set{x=(141-allOffset)}
    end
end

local function dataUI()
    local speedDataLen = #tostring(speedData)
    local powerDataLen=#powerData
    local numberAnswer = { 0, 0, 0}
    local sigCoorderr = { 0, 0, 0}
    numberAnswer[1] = speedData % 10
    numberAnswer[2] = speedData // 10 % 10
    numberAnswer[3] = speedData // 100 % 10
    if(speedDataLen==3)then
        objImageGame.speedOne:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.speedTwo:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.speedThree:clear_flag(lvgl.FLAG.HIDDEN)
        sigCoorderr[3]=(112-allOffset)
        sigCoorderr[2]=(148-allOffset)
        sigCoorderr[1]=(184-allOffset)
    elseif(speedDataLen==2)then
        objImageGame.speedOne:add_flag(lvgl.FLAG.HIDDEN)
        objImageGame.speedTwo:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.speedThree:clear_flag(lvgl.FLAG.HIDDEN)
        sigCoorderr[2]=(130-allOffset)
        sigCoorderr[1]=(166-allOffset)
    else
        objImageGame.speedOne:add_flag(lvgl.FLAG.HIDDEN)
        objImageGame.speedTwo:add_flag(lvgl.FLAG.HIDDEN)
        objImageGame.speedThree:clear_flag(lvgl.FLAG.HIDDEN)
        sigCoorderr[1]=(148-allOffset)
    end
    rImageOne = string.format("/superman/%d.rle", numberAnswer[3])
    objImageGame.speedOne:set{src=imgPath(rImageOne),x=sigCoorderr[3]}
    rImageTwo = string.format("/superman/%d.rle", numberAnswer[2])
    objImageGame.speedTwo:set{src=imgPath(rImageTwo),x=sigCoorderr[2]}
    rImageThree = string.format("/superman/%d.rle", numberAnswer[1])
    objImageGame.speedThree:set{src=imgPath(rImageThree),x=sigCoorderr[1]}
    if(powerDataLen==5)then
        objImageGame.dynamicsOne:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.dynamicsTwo:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.dynamicsThree:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.dynamicsFour:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.dynamics:clear_flag(lvgl.FLAG.HIDDEN)
        dynamicsone = string.sub(powerData,1,1)..".rle"
        dynamicsTwo = string.sub(powerData,2,2)..".rle"
        dynamicsThree = string.sub(powerData,4,4)..".rle"
        dynamicsFour = string.sub(powerData,5,5)..".rle"
        Ones = string.format("/superman/"..dynamicsone)
        objImageGame.dynamicsOne:set{src=imgPath(Ones),x=(87-allOffset)}
        One = string.format("/superman/"..dynamicsTwo)
        objImageGame.dynamicsTwo:set{src=imgPath(One),x=(123-allOffset)}
        Two = string.format("/superman/"..dynamicsThree)
        objImageGame.dynamicsThree:set{src=imgPath(Two),x=(173-allOffset)}
        Three = string.format("/superman/"..dynamicsTwo)
        objImageGame.dynamicsFour:set{src=imgPath(Three),x=(209-allOffset)}
        objImageGame.dynamics:set{x=(159-allOffset)}
    else
        objImageGame.dynamicsOne:add_flag(lvgl.FLAG.HIDDEN)
        objImageGame.dynamicsTwo:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.dynamicsThree:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.dynamicsFour:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.dynamics:clear_flag(lvgl.FLAG.HIDDEN)
        dynamicsTwo = string.sub(powerData,1,1)..".rle"
        dynamicsThree = string.sub(powerData,3,3)..".rle"
        dynamicsFour = string.sub(powerData,4,4)..".rle"
        One = string.format("/superman/"..dynamicsTwo)
        objImageGame.dynamicsTwo:set{src=imgPath(One),x=(105-allOffset)}
        Two = string.format("/superman/"..dynamicsThree)
        objImageGame.dynamicsThree:set{src=imgPath(Two),x=(155-allOffset)}
        Three = string.format("/superman/"..dynamicsFour)
        objImageGame.dynamicsFour:set{src=imgPath(Three),x=(191-allOffset)}
        objImageGame.dynamics:set{x=(141-allOffset)}
    end
end

local function numData()
    screenOFFCb()
    local vibr_id2 = vibrator.start {type = vibrator.type.SUCCESS}
    if(timerf~=0)then
        timerf:delete()
        timerf=0
        timerfData=3
    end
    if(tShow~=0)then
        tShow:delete()
        tShow=0
    end
    printf("--------sumMax-----------",sumMax)
    local dataG, dataS = dataAx()
    speedData = math.floor(dataS)
    powerDatanum = dataG
    printf("--------speedData-----------",speedData)
    printf("--------powerDatanum-----------",powerDatanum)
    printf("--------j-----------",j)
    if(powerDatanum < 50 )then
        powerData = string.format("%.2f",powerDatanum)
    else
        powerData = '50.00'
    end
    if(powerDatanum >= 3)then
        if(powerDatanum<=12)then
            objImageGame.gradeImage:set{src=imgPath("/superman/small.rle")}
        elseif(powerDatanum<=18)then
            objImageGame.gradeImage:set{src=imgPath("/superman/medium.rle")}
        else
            objImageGame.gradeImage:set{src=imgPath("/superman/excellent.rle")}
        end
        objImageGame.objImage:set{src=imgPath("/superman/databg.rle")}
        objImageGame.startRoot:clear_flag(lvgl.FLAG.HIDDEN)
        objImageGame.recurRoot:clear_flag(lvgl.FLAG.HIDDEN)
        dataUI()

        if(powerDatanum > tonumber(powerrecordData))then
        -- 原来这里是根据速度来的
        -- if(speedData > tonumber(speedrecordData))then
            writeData()
            -- todo
            objImageGame.newRecordRoot:clear_flag(lvgl.FLAG.HIDDEN)
			speedrecordData=speedData
			powerrecordData=powerData
        end
    else
        objImageGame.objImage:set{src=imgPath("/superman/filebg.rle")}
        objImageGame.recurRoot:clear_flag(lvgl.FLAG.HIDDEN)
    end
    sumMax=0;
    psumMax = {}
    j = 0;
end

local function screenONCb()
    t = topic.subscribe("sensor_accel", 0, function(topic, status, value)
        if status ~= 0 or not value or #value == 0 then
            printf("data update failed")
            return
        end
        printf("data update value.len",#value)
        printf("data update value.y",value[1].y)
        printf("data update value.x",value[1].x)
        printf("data update value.z",value[1].z)
        printf("data update value.time",value[1].timestamp)
        printf("data update value.temperature",value.temperature)
        dataRSA(value)
    end)
end

local function timerFile()
    screenONCb()
    if(timerf~=0)then
        timerf:delete()
        timerf=0
        timerfData=3
    end
    objImageGame.smallTimerImage:set{src=imgPath("/superman/3.rle")}
    timerf=lvgl.Timer {
        period = 1000,
        cb = function(t)
            -- todo 做一个3秒的记数
            if (timerfData==1) then
                timerfData = 3
                numData()
            else
                timerfData=timerfData-1
                local smallTimerImageSrc = string.format("/superman/%d.rle", timerfData)
                objImageGame.smallTimerImage:set{src=imgPath(smallTimerImageSrc)}
            end
        end
    }
end

local function timer()
    if(tShow~=0)then
        tShow:delete()
        tShow=0
    end
    objImageGame.timerImage:set{src=imgPath("/superman/t3.rle")}
    local vibr_id = vibrator.start {type = vibrator.type.KEY_BOARD}
    tShow=lvgl.Timer {
        period = 1000,
        cb = function(t)
            if(timerData==1)then
                objImageGame.timerRoot:add_flag(lvgl.FLAG.HIDDEN)
                objImageGame.root:clear_flag(lvgl.FLAG.HIDDEN)
                objImageGame.objImage:set{src=imgPath("/superman/nobg.rle")}
                timerData = 3
                local vibr_id1 = vibrator.start {type = vibrator.type.WATCH_FACE}
                tShow:delete()
                tShow=0
                timerFile()
            else
                local vibr_id = vibrator.start {type = vibrator.type.KEY_BOARD}
                timerData=timerData-1
                srcSlider = string.format("/superman/t%d.rle", timerData)
                objImageGame.timerImage:set{src=imgPath(srcSlider)}
            end
        end
    }
end

local function timeronCreate()
    objImageGame.timerRoot = lvgl.Object(root, {
        outline_width = 0,
        border_width = 0,
        pad_all = 0,
        bg_opa = 0,
        bg_color = 0,
        w = 192,
        h = 490,
    })
    objImageGame.timerRoot:add_flag(lvgl.FLAG.HIDDEN)
    local objImage = lvgl.Image(objImageGame.timerRoot,{x = 0, y = 0,src=imgPath("/superman/timerbg.rle")})
    objImageGame.timerImage = lvgl.Image(objImageGame.timerRoot,{x = 50, y = 84,src=imgPath("/superman/t3.rle")})
    objImage:add_flag(lvgl.FLAG.CLICKABLE)
    objImage:clear_flag(lvgl.FLAG.GESTURE_BUBBLE)
    objImage:onevent(lvgl.EVENT.GESTURE,function(obj, code)
        if(tShow~=0)then
            tShow:delete()
            tShow=0
        end
        timerData = 3
        bgEventCB(code)
    end)
end

local function startonCreate()
    objImageGame.root = lvgl.Object(root, {
        outline_width = 0,
        border_width = 0,
        pad_all = 0,
        bg_opa = 0,
        bg_color = 0,
        w = 192,
        h = 490,
    })
    objImageGame.startRoot = lvgl.Object(root, {
        outline_width = 0,
        border_width = 0,
        pad_all = 0,
        bg_opa = 0,
        bg_color = 0,
        w = 192,
        h = 490,
    })
    objImageGame.recurRoot = lvgl.Object(root, {
        outline_width = 0,
        border_width = 0,
        pad_all = 0,
        bg_opa = 0,
        bg_color = 0,
        w = 192,
        h = 490,
    })
    -- todo 新纪录弹框
    objImageGame.newRecordRoot = lvgl.Object(root, {
        outline_width = 0,
        border_width = 0,
        pad_all = 0,
        bg_color = "#000",
        bg_opa = lvgl.OPA(60),
        w = 192,
        h = 490,
    })
    objImageGame.newRecordRoot:add_flag(lvgl.FLAG.HIDDEN)
    local newRecordImage = lvgl.Image(objImageGame.newRecordRoot,{x = 0, y = 108,src=imgPath("/superman/newrecord.bin"),})
    objImageGame.newRecordRoot:add_flag(lvgl.FLAG.CLICKABLE)
    objImageGame.newRecordRoot:onClicked(function ()
        objImageGame.newRecordRoot:add_flag(lvgl.FLAG.HIDDEN)
    end)

    objImageGame.startRoot:add_flag(lvgl.FLAG.HIDDEN)
    objImageGame.root:add_flag(lvgl.FLAG.HIDDEN)
    objImageGame.recurRoot:add_flag(lvgl.FLAG.HIDDEN)
    objImageGame.objImage = lvgl.Image(objImageGame.root,{x = 0, y = 0,src=imgPath("/superman/nobg.rle")})
    -- todo 采集数据时，底部小倒计时，3秒
    objImageGame.smallTimerImage = lvgl.Image(objImageGame.objImage,{x = 75, y = 400,src=imgPath("/superman/3.rle")})
    
    -- 记录数据 todo
    -- objImageGame.testLabel1 = lvgl.Label(objImageGame.objImage, {
    --     x = 20, y = 50,
    --     text_font = lvgl.Font("montserrat", 20, "normal"),
    --     text = "Hello Font",
    --     text_color = "#000",
    -- })
    -- objImageGame.testLabel2 = lvgl.Label(objImageGame.objImage, {
    --     x = 20, y = 70,
    --     text_font = lvgl.Font("montserrat", 20, "normal"),
    --     text = "Hello Font",
    --     text_color = "#000",
    -- })
    -- objImageGame.testLabel3 = lvgl.Label(objImageGame.objImage, {
    --     x = 20, y = 90,
    --     text_font = lvgl.Font("montserrat", 20, "normal"),
    --     text = "Hello Font",
    --     text_color = "#000",
    -- })
    -- objImageGame.testLabel4 = lvgl.Label(objImageGame.objImage, {
    --     x = 20, y = 350,
    --     text_font = lvgl.Font("montserrat", 20, "normal"),
    --     text = "Hello Font",
    --     text_color = "#000",
    -- })

    objImageGame.gradeImage = lvgl.Image(objImageGame.startRoot,{x = 82, y = 51,src=imgPath("/superman/excellent.rle")})
    objImageGame.dynamicsOne = lvgl.Image(objImageGame.startRoot,{x = (87-allOffset), y = 156,src=imgPath("/superman/9.rle")})
    objImageGame.dynamicsTwo = lvgl.Image(objImageGame.startRoot,{x = (123-allOffset), y = 156,src=imgPath("/superman/9.rle")})
    objImageGame.dynamicsThree = lvgl.Image(objImageGame.startRoot,{x = (173-allOffset), y = 156,src=imgPath("/superman/9.rle")})
    objImageGame.dynamicsFour = lvgl.Image(objImageGame.startRoot,{x = (209-allOffset), y = 156,src=imgPath("/superman/9.rle")})
    objImageGame.dynamics = lvgl.Image(objImageGame.startRoot,{x = (159-allOffset), y = 156,src=imgPath("/superman/10.rle")})
    objImageGame.speedOne = lvgl.Image(objImageGame.startRoot,{x = (112-allOffset), y = 293,src=imgPath("/superman/9.rle")})
    objImageGame.speedTwo = lvgl.Image(objImageGame.startRoot,{x = (148-allOffset), y = 293,src=imgPath("/superman/9.rle")})
    objImageGame.speedThree = lvgl.Image(objImageGame.startRoot,{x = (184-allOffset), y = 293,src=imgPath("/superman/9.rle")})
    objImageGame.recurImage = lvgl.Image(objImageGame.recurRoot,{x = 25, y = 395,src=imgPath("/superman/recur.rle")})
    objImageGame.recurImage:add_flag(lvgl.FLAG.CLICKABLE)
    objImageGame.recurImage:onClicked(function ()
        objImageGame.root:add_flag(lvgl.FLAG.HIDDEN)
        objImageGame.startRoot:add_flag(lvgl.FLAG.HIDDEN)
        objImageGame.recurRoot:add_flag(lvgl.FLAG.HIDDEN)
        objImageGame.timerRoot:clear_flag(lvgl.FLAG.HIDDEN)
        timer()
    end)
    objImageGame.objImage:add_flag(lvgl.FLAG.CLICKABLE)
    objImageGame.recurRoot:clear_flag(lvgl.FLAG.CLICKABLE)
    objImageGame.startRoot:clear_flag(lvgl.FLAG.CLICKABLE)
    objImageGame.objImage:clear_flag(lvgl.FLAG.GESTURE_BUBBLE)
    objImageGame.objImage:onevent(lvgl.EVENT.GESTURE,function(obj, code)
        if(timerf~=0)then
            timerf:delete()
            timerf=0
            timerfData=3
        end
        bgEventCB(code)
        screenOFFCb()
    end)
end

local function historyonCreate()
    objImageGame.historyRoot = lvgl.Object(root, {
        outline_width = 0,
        border_width = 0,
        pad_all = 0,
        bg_opa = 0,
        bg_color = 0,
        w = 192,
        h = 490,
    })
    objImageGame.historyRoot:add_flag(lvgl.FLAG.HIDDEN)
    local objImage = lvgl.Image(objImageGame.historyRoot,{x = 0, y = 0,src=imgPath("/superman/historybg.rle")})
    local beginImage = lvgl.Image(objImageGame.historyRoot,{x = 25, y = 395,src=imgPath("/superman/begin2.rle")})
    objImageGame.hdynamicsOne = lvgl.Image(objImageGame.historyRoot,{x = (87-allOffset), y = 156,src=imgPath("/superman/9.rle")})
    objImageGame.hdynamicsTwo = lvgl.Image(objImageGame.historyRoot,{x = (123-allOffset), y = 156,src=imgPath("/superman/9.rle")})
    objImageGame.hdynamicsThree = lvgl.Image(objImageGame.historyRoot,{x = (173-allOffset), y = 156,src=imgPath("/superman/9.rle")})
    objImageGame.hdynamicsFour = lvgl.Image(objImageGame.historyRoot,{x = (209-allOffset), y = 156,src=imgPath("/superman/9.rle")})
    objImageGame.hdynamics = lvgl.Image(objImageGame.historyRoot,{x = (159-allOffset), y = 156,src=imgPath("/superman/10.rle")})
    objImageGame.hspeedOne = lvgl.Image(objImageGame.historyRoot,{x = (112-allOffset), y = 293,src=imgPath("/superman/9.rle")})
    objImageGame.hspeedTwo = lvgl.Image(objImageGame.historyRoot,{x = (148-allOffset), y = 293,src=imgPath("/superman/9.rle")})
    objImageGame.hspeedThree = lvgl.Image(objImageGame.historyRoot,{x = (184-allOffset), y = 293,src=imgPath("/superman/9.rle")})
    beginImage:add_flag(lvgl.FLAG.CLICKABLE)
    beginImage:onClicked(function ()
        objImageGame.historyRoot:add_flag(lvgl.FLAG.HIDDEN)
        objImageGame.timerRoot:clear_flag(lvgl.FLAG.HIDDEN)
        timer()
    end)
    objImage:add_flag(lvgl.FLAG.CLICKABLE)
    objImage:clear_flag(lvgl.FLAG.GESTURE_BUBBLE)
    objImage:onevent(lvgl.EVENT.GESTURE,function(obj, code)
        bgEventCB(code)
    end)
end

local function explainonCreate()
    objImageGame.explainRoot = lvgl.Object(root, {
        outline_width = 0,
        border_width = 0,
        pad_all = 0,
        bg_opa = 0,
        bg_color = 0,
        w = 192,
        h = 490,
    })
    objImageGame.explainRoot:add_flag(lvgl.FLAG.HIDDEN)
    local objImage = lvgl.Image(objImageGame.explainRoot,{x = 0, y = 0,src=imgPath("/superman/explainbg.rle"),})
    local goImage = lvgl.Image(objImageGame.explainRoot,{x = 25, y = 395,src=imgPath("/superman/go.rle")})
    goImage:add_flag(lvgl.FLAG.CLICKABLE)
    goImage:onClicked(function ()
        objImageGame.explainRoot:add_flag(lvgl.FLAG.HIDDEN)
        objImageGame.supermanRoot:clear_flag(lvgl.FLAG.HIDDEN)
    end)
    objImage:add_flag(lvgl.FLAG.CLICKABLE)
    objImage:clear_flag(lvgl.FLAG.GESTURE_BUBBLE)
    objImage:onevent(lvgl.EVENT.GESTURE,function(obj, code)
        bgEventCB(code)
    end)
end

local function supermansonCreate()
    objImageGame.supermanRoot = lvgl.Object(root, {
        outline_width = 0,
        border_width = 0,
        pad_all = 0,
        bg_opa = 0,
        bg_color = 0,
        w = 192,
        h = 490,
    })
    local objImage = lvgl.Image(objImageGame.supermanRoot,{x = 0, y = 0,src=imgPath("/superman/bg.rle")})
    local beginImage = lvgl.Image(objImageGame.supermanRoot,{x = 0, y = 270,src=imgPath("/superman/begin.rle")})
    local historyImage = lvgl.Image(objImageGame.supermanRoot,{x = 33, y = 330,src=imgPath("/superman/history.rle")})
    local explainImage = lvgl.Image(objImageGame.supermanRoot,{x = 75, y = 428,src=imgPath("/superman/explain.rle")})
    beginImage:add_flag(lvgl.FLAG.CLICKABLE)
    historyImage:add_flag(lvgl.FLAG.CLICKABLE)
    explainImage:add_flag(lvgl.FLAG.CLICKABLE)
    beginImage:onClicked(function ()
        objImageGame.supermanRoot:add_flag(lvgl.FLAG.HIDDEN)
        objImageGame.timerRoot:clear_flag(lvgl.FLAG.HIDDEN)
        timer()
    end)
    historyImage:onClicked(function ()
        objImageGame.supermanRoot:add_flag(lvgl.FLAG.HIDDEN)
        objImageGame.historyRoot:clear_flag(lvgl.FLAG.HIDDEN)
        recordData();
    end)
    explainImage:onClicked(function ()
        objImageGame.supermanRoot:add_flag(lvgl.FLAG.HIDDEN)
        objImageGame.explainRoot:clear_flag(lvgl.FLAG.HIDDEN)
    end)
end
bgEventCB = function (event)
    objImageGame.historyRoot:add_flag(lvgl.FLAG.HIDDEN)
    objImageGame.explainRoot:add_flag(lvgl.FLAG.HIDDEN)
    objImageGame.root:add_flag(lvgl.FLAG.HIDDEN)
    objImageGame.startRoot:add_flag(lvgl.FLAG.HIDDEN)
    objImageGame.timerRoot:add_flag(lvgl.FLAG.HIDDEN)
    objImageGame.supermanRoot:clear_flag(lvgl.FLAG.HIDDEN)
    objImageGame.recurRoot:add_flag(lvgl.FLAG.HIDDEN)
end
local function onCreate()
    supermansonCreate()
    explainonCreate()
    historyonCreate()
    startonCreate()
    timeronCreate()
    readData()
end
onCreate(bgEventCB)