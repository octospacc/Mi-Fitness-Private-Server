

local lvgl = require("lvgl")



num=0;

leftOrRight=0;

objImageGame = {};

t=0;

s=12;

tShow=0;



local fsRoot = SCRIPT_PATH

local DEBUG_ENABLE = true



local printf = DEBUG_ENABLE and print or function (...)

end



function imgPath(src)

    return fsRoot .. "game/" .. src

end



local function resetDate(objRoot)

    objRoot:add_flag(lvgl.FLAG.HIDDEN)

    num=0;

    s=12;

    randomNumber();

end

local function exitDate()

    objImageGame.root:add_flag(lvgl.FLAG.HIDDEN)

    if(t~=0)then

        t:delete()

        t=0

    end

    if(tShow~=0)then

        tShow:delete()

        tShow=0

    end



    navigator.finish {

        appID = 0x38, -- lua

        pageId = 0,

    }

end

local function getUpdate()

    local getOne =num//10;

    local getTwo =num%10;

    if(getOne>0)then

        objImageGame.getImageTwo:clear_flag(lvgl.FLAG.HIDDEN)

        getImageOne= string.format("get%d.rle", getOne)

        objImageGame.getImageOne:set{src = imgPath(getImageOne)}

        getImageTwo = string.format("get%d.rle", getTwo)

        objImageGame.getImageTwo:set{src = imgPath(getImageTwo)}

    else

        getImageOne= string.format("get%d.rle", getTwo)

        objImageGame.getImageOne:set{src = imgPath(getImageOne)}

        objImageGame.getImageTwo:add_flag(lvgl.FLAG.HIDDEN)

    end

end

local function getFileDate()

    objImageGame.fileRoot:clear_flag(lvgl.FLAG.HIDDEN);

    local getOne =num//10;

    local getTwo =num%10;

    if(getOne>0)then

        fileGetImageOne= string.format("file%d.rle", getOne)

        objImageGame.fileGetImageOne:set{src = imgPath(fileGetImageOne)}

        fileGetImageTwo = string.format("file%d.rle", getTwo)

        objImageGame.fileGetImageOne:clear_flag(lvgl.FLAG.HIDDEN);

        objImageGame.fileGetImageTwo:set{src = imgPath(fileGetImageTwo),x=100}

    else

        fileGetImageTwo= string.format("file%d.rle", getTwo)

        objImageGame.fileGetImageTwo:set{src = imgPath(fileGetImageTwo),x=75}

        objImageGame.fileGetImageOne:add_flag(lvgl.FLAG.HIDDEN)

    end

end

local function showUpdate(index)

    if(index==1)then

        objImageGame.wrongImage:clear_flag(lvgl.FLAG.HIDDEN)

    else

        objImageGame.rightImage:clear_flag(lvgl.FLAG.HIDDEN)

    end

end

answerOr=function(correct,index)

    if(correct)then

        num=num+1

        getUpdate();

        showUpdate(index);

        tShow=lvgl.Timer {

            period = 1000,

            cb = function(t)

                if(num==100)then

                    objImageGame.succeedRoot:clear_flag(lvgl.FLAG.HIDDEN);

                else

                    randomNumber()

                end

                if(tShow~=0)then

                    tShow:delete()

                    tShow=0

                end

            end

        }

        if(t~=0)then

            t:delete()

            t=0

        end

    else

        showUpdate(index);

        if(t~=0)then

            t:delete()

            t=0

        end

        tShow=lvgl.Timer {

            period = 1000,

            cb = function(t)

                getFileDate()

                if(tShow~=0)then

                    tShow:delete()

                    tShow=0

                end

            end

        }

    end

end

local function timeUpdate()

    srcOne = string.format("t%d.rle", s // 10)

    objImageGame.minImageOne:set{src = imgPath(srcOne)}

    srcTwo = string.format("t%d.rle", s % 10)

    objImageGame.minImageTwo:set{src = imgPath(srcTwo)}

    srcSlider = string.format("s%d.rle", s)

    objImageGame.sliderImage:set{src = imgPath(srcSlider)}

end

local timer=function ()

    if(num>=50)then

        s=2

    else

        local numData=(num//10)*2

        s=12-numData

    end

    timeUpdate();

    if(t~=0)then

        t:delete()

        t=0

    end

    t=lvgl.Timer {

        period = 1000,

        cb = function(t)

            if(s==0)then

                getFileDate()

                t:delete()

                t=0

            else

                s=s-1

                timeUpdate();

            end

        end

    }

end

local function topicUpdate()

    local one = math.random(99);

    local sigOne =one//10;

    local sigTwo =one%10;

    if(sigOne>0)then

        objImageGame.topImageOne:clear_flag(lvgl.FLAG.HIDDEN)

        topImageOne = string.format("top%d.rle", sigOne)

        objImageGame.topImageOne:set{src = imgPath(topImageOne)}

    else

        objImageGame.topImageOne:add_flag(lvgl.FLAG.HIDDEN)

    end

    topImageTwo = string.format("top%d.rle", sigTwo)

    objImageGame.topImageTwo:set{src = imgPath(topImageTwo)}

    local two = math.random(99);

    local sigThree =two//10;

    local sigFour =two%10;

    if(sigThree>0)then

        objImageGame.topImageFour:clear_flag(lvgl.FLAG.HIDDEN)

        srcThree= string.format("top%d.rle", sigThree)

        objImageGame.topImageThree:set{src = imgPath(srcThree)}

        srcFour = string.format("top%d.rle", sigFour)

        objImageGame.topImageFour:set{src = imgPath(srcFour)}

    else

        srcThree= string.format("top%d.rle", sigFour)

        objImageGame.topImageThree:set{src = imgPath(srcThree)}

        objImageGame.topImageFour:add_flag(lvgl.FLAG.HIDDEN)

    end



    local ma = math.random(3);

    sigImage = string.format("sig%d.rle", ma)

    objImageGame.sigImage:set{src = imgPath(sigImage)}

    local answer = 0

    if(ma==1)then

        answer=one+two

    elseif(ma==2)then

        answer=one-two

    else

        answer=one*two

    end

    return answer;

end

local function sigCoord(answerLen,errorDataLen)

    local sigCoordan = {0,0,0,0};

    local sigCoorderr = {0,0,0,0};

    if(leftOrRight==1)then

        if(errorDataLen==4)then

            sigCoorderr[4]=60

            sigCoorderr[3]=78

            sigCoorderr[2]=96

            sigCoorderr[1]=115

        elseif(errorDataLen==3)then

            sigCoorderr[3]=70

            sigCoorderr[2]=88

            sigCoorderr[1]=106

        elseif(errorDataLen==2)then

            sigCoorderr[2]=78

            sigCoorderr[1]=96

        else

            sigCoorderr[1]=90

        end

        if(answerLen==4)then

            sigCoordan[4]=60

            sigCoordan[3]=78

            sigCoordan[2]=96

            sigCoordan[1]=115

        elseif(answerLen==3)then

            sigCoordan[3]=70

            sigCoordan[2]=88

            sigCoordan[1]=106

        elseif(answerLen==2)then

            sigCoordan[2]=78

            sigCoordan[1]=96

        else

            sigCoordan[1]=90

        end

    else

        if(answerLen==4)then

            sigCoordan[4]=60

            sigCoordan[3]=78

            sigCoordan[2]=96

            sigCoordan[1]=115

        elseif(answerLen==3)then

            sigCoordan[3]=70

            sigCoordan[2]=88

            sigCoordan[1]=106

        elseif(answerLen==2)then

            sigCoordan[2]=78

            sigCoordan[1]=96

        else

            sigCoordan[1]=90

        end

        if(errorDataLen==4)then

            sigCoorderr[4]=60

            sigCoorderr[3]=78

            sigCoorderr[2]=96

            sigCoorderr[1]=115

        elseif(errorDataLen==3)then

            sigCoorderr[3]=70

            sigCoorderr[2]=88

            sigCoorderr[1]=106

        elseif(errorDataLen==2)then

            sigCoorderr[2]=78

            sigCoorderr[1]=96

        else

            sigCoorderr[1]=90

        end

    end

    return sigCoordan, sigCoorderr

end

local function sigUpdate(answer,errorData)

    local answerMinus = false;

    local errorDataMinus = false;

    local answerLen = #tostring(answer);

    local errorDataLen=#tostring(errorData)

    leftOrRight = math.random(2);

    local sigCoordan,sigCoorderr = sigCoord(answerLen,errorDataLen);

    if(answer<0)then

        answer = math.abs(answer);

        answerMinus = true;

    end

    if(errorData<0)then

        errorData = math.abs(errorData);

        errorDataMinus = true;

    end

    local numberAnswer = { 0, 0, 0, 0}

    numberAnswer[1] = answer % 10

    numberAnswer[2] = answer // 10 % 10

    numberAnswer[3] = answer // 100 % 10

    numberAnswer[4] = answer // 1000 % 10

    local numberErrorData = { 0, 0, 0, 0}

    numberErrorData[1] = errorData % 10

    numberErrorData[2] = errorData // 10 % 10

    numberErrorData[3] = errorData // 100 % 10

    numberErrorData[4] = errorData // 1000 % 10

    if(answerMinus)then

        numberAnswer[answerLen] = 10;

    end

    if(errorDataMinus)then

        numberErrorData[errorDataLen]=10;

    end



    if(leftOrRight==1)then

        if(answerLen==4)then

            objImageGame.rImageOne:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageTwo:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageThree:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageFour:clear_flag(lvgl.FLAG.HIDDEN)

        elseif(answerLen==3)then

            objImageGame.rImageOne:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageTwo:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageThree:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageFour:clear_flag(lvgl.FLAG.HIDDEN)

        elseif(answerLen==2)then

            objImageGame.rImageOne:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageTwo:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageThree:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageFour:clear_flag(lvgl.FLAG.HIDDEN)

        else

            objImageGame.rImageOne:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageTwo:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageThree:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageFour:clear_flag(lvgl.FLAG.HIDDEN)

        end

        if(errorDataLen==4)then

            objImageGame.lImageOne:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageTwo:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageThree:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageFour:clear_flag(lvgl.FLAG.HIDDEN)

        elseif(errorDataLen==3)then

            objImageGame.lImageOne:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageTwo:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageThree:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageFour:clear_flag(lvgl.FLAG.HIDDEN)

        elseif(errorDataLen==2)then

            objImageGame.lImageOne:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageTwo:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageThree:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageFour:clear_flag(lvgl.FLAG.HIDDEN)

        else

            objImageGame.lImageOne:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageTwo:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageThree:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageFour:clear_flag(lvgl.FLAG.HIDDEN)

        end

        rImageOne = string.format("%d.rle", numberAnswer[4])

        objImageGame.rImageOne:set{src = imgPath(rImageOne),x=sigCoordan[4]}

        rImageTwo = string.format("%d.rle", numberAnswer[3])

        objImageGame.rImageTwo:set{src = imgPath(rImageTwo),x=sigCoordan[3]}

        rImageThree = string.format("%d.rle", numberAnswer[2])

        objImageGame.rImageThree:set{src = imgPath(rImageThree),x=sigCoordan[2]}

        rImageFour = string.format("%d.rle", numberAnswer[1])

        objImageGame.rImageFour:set{src = imgPath(rImageFour),x=sigCoordan[1]}

        lImageOne = string.format("%d.rle", numberErrorData[4])

        objImageGame.lImageOne:set{src = imgPath(lImageOne),x=sigCoorderr[4]}

        lImageTwo = string.format("%d.rle", numberErrorData[3])

        objImageGame.lImageTwo:set{src = imgPath(lImageTwo),x=sigCoorderr[3]}

        lImageThree = string.format("%d.rle", numberErrorData[2])

        objImageGame.lImageThree:set{src = imgPath(lImageThree),x=sigCoorderr[2]}

        lImageFour = string.format("%d.rle", numberErrorData[1])

        objImageGame.lImageFour:set{src = imgPath(lImageFour),x=sigCoorderr[1]}

        objImageGame.wrongImage:set{src = imgPath("right.rle")}

        objImageGame.rightImage:set{src = imgPath("wrong.rle")}

    else

        if(errorDataLen==4)then

            objImageGame.rImageOne:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageTwo:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageThree:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageFour:clear_flag(lvgl.FLAG.HIDDEN)

        elseif(errorDataLen==3)then

            objImageGame.rImageOne:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageTwo:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageThree:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageFour:clear_flag(lvgl.FLAG.HIDDEN)

        elseif(errorDataLen==2)then

            objImageGame.rImageOne:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageTwo:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageThree:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageFour:clear_flag(lvgl.FLAG.HIDDEN)

        else

            objImageGame.rImageOne:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageTwo:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageThree:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.rImageFour:clear_flag(lvgl.FLAG.HIDDEN)

        end

        if(answerLen==4)then

            objImageGame.lImageOne:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageTwo:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageThree:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageFour:clear_flag(lvgl.FLAG.HIDDEN)

        elseif(answerLen==3)then

            objImageGame.lImageOne:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageTwo:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageThree:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageFour:clear_flag(lvgl.FLAG.HIDDEN)

        elseif(answerLen==2)then

            objImageGame.lImageOne:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageTwo:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageThree:clear_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageFour:clear_flag(lvgl.FLAG.HIDDEN)

        else

            objImageGame.lImageOne:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageTwo:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageThree:add_flag(lvgl.FLAG.HIDDEN)

            objImageGame.lImageFour:clear_flag(lvgl.FLAG.HIDDEN)

        end

        rImageOne = string.format("%d.rle", numberErrorData[4])

        objImageGame.rImageOne:set{src = imgPath(rImageOne),x=sigCoorderr[4]}

        rImageTwo = string.format("%d.rle", numberErrorData[3])

        objImageGame.rImageTwo:set{src = imgPath(rImageTwo),x=sigCoorderr[3]}

        rImageThree = string.format("%d.rle", numberErrorData[2])

        objImageGame.rImageThree:set{src = imgPath(rImageThree),x=sigCoorderr[2]}

        rImageFour = string.format("%d.rle", numberErrorData[1])

        objImageGame.rImageFour:set{src = imgPath(rImageFour),x=sigCoorderr[1]}

        lImageOne = string.format("%d.rle", numberAnswer[4])

        objImageGame.lImageOne:set{src = imgPath(lImageOne),x=sigCoordan[4]}

        lImageTwo = string.format("%d.rle", numberAnswer[3])

        objImageGame.lImageTwo:set{src = imgPath(lImageTwo),x=sigCoordan[3]}

        lImageThree = string.format("%d.rle", numberAnswer[2])

        objImageGame.lImageThree:set{src = imgPath(lImageThree),x=sigCoordan[2]}

        lImageFour = string.format("%d.rle", numberAnswer[1])

        objImageGame.lImageFour:set{src = imgPath(lImageFour),x=sigCoordan[1]}

        objImageGame.rightImage:set{src = imgPath("right.rle")}

        objImageGame.wrongImage:set{src = imgPath("wrong.rle")}

    end

    objImageGame.rightImage:add_flag(lvgl.FLAG.HIDDEN)

    objImageGame.wrongImage:add_flag(lvgl.FLAG.HIDDEN)

    objImageGame.upObj:add_flag(lvgl.FLAG.CLICKABLE)

    objImageGame.downObj:add_flag(lvgl.FLAG.CLICKABLE)

end

randomNumber=function ()

    getUpdate();

    local answer = topicUpdate();

    local errorData = errorMessage(answer)

    sigUpdate(answer,errorData);

    timer()

end

errorMessage=function(answer)

    local data = math.random(6);

    local errorData = 0;

    if(data==1)then

        errorData=answer+1

    elseif(data==2)then

        errorData=answer+10

    elseif(data==3)then

        errorData=answer+100

    elseif(data==4)then

        errorData=answer-1

    elseif(data==5)then

        errorData=answer-10

    else

        errorData=answer-100

    end

    return errorData;

end

local function imgaeCreateGame(src,pos)

    local objImage = lvgl.Image(objImageGame.root,{x = pos.x, y = pos.y,src = src,})

    return objImage;

end

local function view_init()

    objImageGame.root = lvgl.Object(nil, {

        outline_width = 0,

        border_width = 0,

        pad_all = 0,

        bg_opa = 0,

        bg_color = 0,

        w = 192,

        h = 490,

    })

    --bg

    objImageGame.bgImage = imgaeCreateGame(imgPath("bg.rle"),{x = 0, y = 0});

    --进度条

    objImageGame.sliderImage = imgaeCreateGame(imgPath("s1.rle"),{x =12, y = 8});

    --时间

    objImageGame.hourImageOne = imgaeCreateGame(imgPath("t0.rle"),{x = 64, y = 24});

    objImageGame.hourImageTwo = imgaeCreateGame(imgPath("t0.rle"),{x = 77, y = 24});

    objImageGame.minImageOne = imgaeCreateGame(imgPath("t1.rle"),{x = 97, y = 24});

    objImageGame.minImageTwo = imgaeCreateGame(imgPath("t2.rle"),{x = 110, y = 24});

    objImageGame.minImage = imgaeCreateGame(imgPath("t.rle"),{x = 90, y = 22});

    --得分

    objImageGame.getImageOne = imgaeCreateGame(imgPath("get0.rle"),{x = 93, y = 58});

    objImageGame.getImageTwo = imgaeCreateGame(imgPath("get9.rle"),{x = 110, y = 58});

    objImageGame.starImage = imgaeCreateGame(imgPath("star.rle"),{x = 56, y = 59});

    --题目

    objImageGame.topImageOne = imgaeCreateGame(imgPath("top1.rle"),{x = 35, y = 130});

    objImageGame.topImageTwo = imgaeCreateGame(imgPath("top5.rle"),{x = 58, y = 130});

    objImageGame.topImageThree = imgaeCreateGame(imgPath("to9.rle"),{x = 106, y = 130});

    objImageGame.topImageFour = imgaeCreateGame(imgPath("top8.rle"),{x = 129, y = 130});

    objImageGame.sigImage = imgaeCreateGame(imgPath("sig1.rle"),{x = 82, y = 130});

    --点击

    objImageGame.upObj = imgaeCreateGame(imgPath("click.rle"),{x=16,y=255});

    objImageGame.downObj = imgaeCreateGame(imgPath("click.rle"),{x=16,y=320});

    objImageGame.upObj:add_flag(lvgl.FLAG.CLICKABLE)

    objImageGame.downObj:add_flag(lvgl.FLAG.CLICKABLE)

    --答案

    objImageGame.lImageOne = imgaeCreateGame(imgPath("8.rle"),{x = 36, y = 265});

    objImageGame.lImageTwo = imgaeCreateGame(imgPath("1.rle"),{x = 54, y = 265});

    objImageGame.lImageThree = imgaeCreateGame(imgPath("1.rle"),{x = 72, y = 265});

    objImageGame.lImageFour = imgaeCreateGame(imgPath("1.rle"),{x = 90, y = 265});



    objImageGame.rImageOne = imgaeCreateGame(imgPath("8.rle"),{x = 80, y = 331});

    objImageGame.rImageTwo = imgaeCreateGame(imgPath("1.rle"),{x = 98, y = 331});

    objImageGame.rImageThree = imgaeCreateGame(imgPath("1.rle"),{x = 116, y = 331});

    objImageGame.rImageFour = imgaeCreateGame(imgPath("1.rle"),{x = 134, y = 331});

    objImageGame.rightImage = imgaeCreateGame(imgPath("right.rle"),{x = 144, y = 237});

    objImageGame.wrongImage = imgaeCreateGame(imgPath("wrong.rle"),{x = 143, y = 308});

    -- --返回

    objImageGame.returnImage = imgaeCreateGame(imgPath("return.rle"),{x = 37, y = 415});

    objImageGame.returnImage:add_flag(lvgl.FLAG.CLICKABLE)

    objImageGame.upObj:onClicked(function ()

        objImageGame.upObj:clear_flag(lvgl.FLAG.CLICKABLE)

        objImageGame.downObj:clear_flag(lvgl.FLAG.CLICKABLE)

        if(leftOrRight == 1)then

            correct = false;

        else

            correct = true;

        end

        answerOr(correct,0);

    end)

    objImageGame.downObj:onClicked(function ()

        objImageGame.upObj:clear_flag(lvgl.FLAG.CLICKABLE)

        objImageGame.downObj:clear_flag(lvgl.FLAG.CLICKABLE)

        if(leftOrRight == 1)then

            correct = true;

        else

            correct = false;

        end

        answerOr(correct,1);

    end)

    objImageGame.returnImage:onClicked(function ()

        exitDate();

    end)

    return objImageGame;

end

local function succeedUpdate()

    objImageGame.succeedRoot = lvgl.Object(objImageGame.root, {

        outline_width = 0,

        border_width = 0,

        pad_all = 0,

        bg_opa = 0,

        bg_color = 0,

        w = 192,

        h = 490,

    })

    objImageGame.succeedImage = lvgl.Image(objImageGame.succeedRoot,{x = 0, y = 0,src = imgPath("succeed.rle")})

    objImageGame.succeedRoot:add_flag(lvgl.FLAG.HIDDEN);

    objImageGame.succeedStart = lvgl.Object(objImageGame.succeedRoot, {

        outline_width = 0,

        border_width = 0,

        pad_all = 0,

        bg_opa = 0,

        bg_color = 0,

        w = 120,

        h = 60,

        x =37,

        y = 415,

    })

    objImageGame.succeedOver = lvgl.Object(objImageGame.succeedRoot, {

        outline_width = 0,

        border_width = 0,

        pad_all = 0,

        bg_opa = 0,

        bg_color = 0,

        w = 120,

        h = 60,

        x =35,

        y = 11,

    })

    objImageGame.succeedStart:add_flag(lvgl.FLAG.CLICKABLE)

    objImageGame.succeedOver:add_flag(lvgl.FLAG.CLICKABLE)

    objImageGame.succeedStart:onClicked(function ()

        resetDate(objImageGame.succeedRoot);

    end)

    objImageGame.succeedOver:onClicked(function ()

        exitDate();

    end)

end

local function failUpdate()

    objImageGame.fileRoot = lvgl.Object(objImageGame.root, {

        outline_width = 0,

        border_width = 0,

        pad_all = 0,

        bg_opa = 0,

        bg_color = 0,

        w = 192,

        h = 490,

    })

    objImageGame.fileImage=lvgl.Image(objImageGame.fileRoot,{x = 0, y = 0,src = imgPath("fail.rle")})

    objImageGame.fileGetImageOne=lvgl.Image(objImageGame.fileRoot,{x = 58, y = 180,src = imgPath("file0.rle")})

    objImageGame.fileGetImageTwo=lvgl.Image(objImageGame.fileRoot,{x = 100, y = 180,src = imgPath("file0.rle")})

    objImageGame.fileRoot:add_flag(lvgl.FLAG.HIDDEN);

    objImageGame.fileStart = lvgl.Object(objImageGame.fileRoot, {

        outline_width = 0,

        border_width = 0,

        pad_all = 0,

        bg_opa = 0,

        bg_color = 0,

        w = 120,

        h = 60,

        x =37,

        y = 415,

    })

    objImageGame.fileOver = lvgl.Object(objImageGame.fileRoot, {

        outline_width = 0,

        border_width = 0,

        pad_all = 0,

        bg_opa = 0,

        bg_color = 0,

        w = 120,

        h = 60,

        x =35,

        y = 11,

    })

    objImageGame.fileStart:add_flag(lvgl.FLAG.CLICKABLE)

    objImageGame.fileOver:add_flag(lvgl.FLAG.CLICKABLE)

    objImageGame.fileStart:onClicked(function ()

        resetDate(objImageGame.fileRoot);

    end)

    objImageGame.fileOver:onClicked(function ()

        exitDate();

    end)

end

local function onCreateGame()

    printf("lvgl game start")

    view_init();

    succeedUpdate();

    failUpdate();

    randomNumber();

end

onCreateGame()